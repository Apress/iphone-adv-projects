#ifndef st_TextureUtils_h_
#define st_TextureUtils_h_

@class UIImage;

namespace TextureUtils
{
	uint Create(UIImage* uiimage);
}


#endif

