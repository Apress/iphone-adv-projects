
#import "EnvironmentMappingAppDelegate.h"
#include "RootViewController.h"

@implementation EnvironmentMappingAppDelegate


- (void)applicationDidFinishLaunching:(UIApplication *)application 
{
	[m_window addSubview:m_viewController.view];
    [m_window makeKeyAndVisible];
}


- (void)applicationWillResignActive:(UIApplication *)application {
//	glView.animationInterval = 1.0 / 5.0;
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
//	glView.animationInterval = 1.0 / 60.0;
}


- (void)dealloc {
	[m_window release];
	[super dealloc];
}

@end
