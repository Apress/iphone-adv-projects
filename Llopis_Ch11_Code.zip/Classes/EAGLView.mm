#import "EAGLView.h"
#include "TextureUtils.h"
#include "Mesh.h"

#import <QuartzCore/QuartzCore.h>
#import <OpenGLES/EAGLDrawable.h>


#define USE_DEPTH_BUFFER 1

struct Mesh;

// A class extension to declare private methods
@interface EAGLView ()

@property (nonatomic, retain) EAGLContext *context;
@property (nonatomic, assign) NSTimer *animationTimer;

- (BOOL) createFramebuffer;
- (void) destroyFramebuffer;

@end


@implementation EAGLView

@synthesize context;
@synthesize animationTimer;
@synthesize animationInterval;
@synthesize m_lightingMode;


// You must implement this method
+ (Class)layerClass {
    return [CAEAGLLayer class];
}



- (id)initWithCoder:(NSCoder*)coder {
    
    if ((self = [super initWithCoder:coder])) {
        // Get the layer
        CAEAGLLayer *eaglLayer = (CAEAGLLayer *)self.layer;
        
        eaglLayer.opaque = YES;
        eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithBool:NO], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];
        
        context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
        
        if (!context || ![EAGLContext setCurrentContext:context]) {
            [self release];
            return nil;
        }

		NSString* meshFilename = [[NSString alloc] initWithFormat:@"%@/Car.obj", [[NSBundle mainBundle] resourcePath]];
		m_mesh = MeshUtils::Create([meshFilename cStringUsingEncoding:NSASCIIStringEncoding]);
		[meshFilename release];

		UIImage* texture = [UIImage imageNamed:@"CarTexture.png"];
		m_texture = TextureUtils::Create(texture);
		UIImage* envMap = [UIImage imageNamed:@"Spheremap.png"];
		m_envMap = TextureUtils::Create(envMap);
		UIImage* envMask = [UIImage imageNamed:@"CarTextureEnvMask.png"];
		m_envMask = TextureUtils::Create(envMask);

        animationInterval = 1.0 / 30.0;
		
		m_xAngle = 20;
		m_yAngle = -220;
    }
    return self;
}


- (void)setupDiffuseLight:(bool)on
{
	if (on)
	{
		glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT0);

		float ambientColor[] = {0.3f, 0.3f, 0.3f, 1.0f};
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientColor);

		float ambientLight[] = { 0.0f, 0.0f, 0.0f, 1.0f };
		float diffuseLight[] = { 0.8f, 0.8f, 0.8f, 1.0f };
		float position[] = { 1.0f, 0.5f, -1.0f, 0.0f };
		glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
		glLightfv(GL_LIGHT0, GL_POSITION, position);

		float white[] = {1.0f, 1.0f, 1.0f, 1.0f};
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, white);
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, white);
	}
	else
	{
		glDisable(GL_LIGHTING);
	}
}

- (void)setupSpecularLight:(bool)on
{
	if (on)
	{
		float white[] = {1.0f, 1.0f, 1.0f, 1.0f};
		glLightfv(GL_LIGHT0, GL_SPECULAR, white);

		glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, white);
		float shininess[] = { 100.0f };
		glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
	}
	else
	{
		float specularColor[] = { 0.0f, 0.0f, 0.0f, 0.0f };
		glLightfv(GL_LIGHT0, GL_SPECULAR, specularColor);
	}
}


- (void)setupLightingMode:(int)pass
{
	switch (m_lightingMode)
	{
	case LightingMode::DiffuseTexture:
		[self setupDiffuseLight:false];
		break;
		
	case LightingMode::DiffuseSpecularLightingAndDiffuseTexture:
		[self setupDiffuseLight:true];
		[self setupSpecularLight:true];
		break;

	case LightingMode::MaskedEnvMapAndLightingAndDiffuseTexture:
		if (pass == 0)
		{
			[self setupDiffuseLight:true];
			[self setupSpecularLight:false];
		}
		break;

	default:
		[self setupDiffuseLight:true];
		[self setupSpecularLight:false];
		break;
	}
}


- (void)setupGeometry:(int)pass
{
	glVertexPointer(3, GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].x);
	glEnableClientState(GL_VERTEX_ARRAY);
	glNormalPointer(GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].nx);
	glEnableClientState(GL_NORMAL_ARRAY);

	glClientActiveTexture(GL_TEXTURE1);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glClientActiveTexture(GL_TEXTURE0);

	switch (m_lightingMode)
	{
	case LightingMode::DiffuseTexture:
	case LightingMode::DiffuseLightingAndDiffuseTexture:
	case LightingMode::DiffuseSpecularLightingAndDiffuseTexture:
		glTexCoordPointer(2, GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].u);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		break;
	case LightingMode::EnvMap:
		glTexCoordPointer(3, GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].nx);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		break;
	case LightingMode::EnvMapAndLightingAndDiffuseTexture:
		glClientActiveTexture(GL_TEXTURE0);
		glTexCoordPointer(2, GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].u);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		
		glClientActiveTexture(GL_TEXTURE1);
		glTexCoordPointer(3, GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].nx);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		break;
	case LightingMode::MaskedEnvMapAndLightingAndDiffuseTexture:
		if (pass == 0)
		{
			glTexCoordPointer(2, GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].u);
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		}
		else
		{
			glClientActiveTexture(GL_TEXTURE0);
			glTexCoordPointer(2, GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].u);
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);
			
			glClientActiveTexture(GL_TEXTURE1);
			glTexCoordPointer(3, GL_FLOAT, sizeof(Vertex), &m_mesh->m_vertices[0].nx);
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		}
		break;
	default:
		break;
	}
	
}


- (void)setupEnvMap
{
	float worldToView[16];
	glGetFloatv(GL_MODELVIEW_MATRIX, worldToView);
	glMatrixMode(GL_TEXTURE);
	float mat[16] = {
		0.5f * worldToView[0], -0.5 * worldToView[4], 0, 0,
		0.5f * worldToView[1], -0.5 * worldToView[5], 0, 0,
		0.5f * worldToView[2], -0.5 * worldToView[6], 0, 0,
		0.5f, 0.5, 0, 1};
	glLoadMatrixf(mat);
	glBindTexture(GL_TEXTURE_2D, m_envMap);
}


- (void)setupTexture:(int)pass
{
	glActiveTexture(GL_TEXTURE0);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glEnable(GL_TEXTURE_2D);
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	
	switch (m_lightingMode)
	{
	case LightingMode::DiffuseTexture:
	case LightingMode::DiffuseLightingAndDiffuseTexture:
	case LightingMode::DiffuseSpecularLightingAndDiffuseTexture:
		glBindTexture(GL_TEXTURE_2D, m_texture);
		glActiveTexture(GL_TEXTURE1);
		glDisable(GL_TEXTURE_2D);
		break;
	case LightingMode::EnvMap:
	{
		[self setupEnvMap];
		break;
	}
	case LightingMode::EnvMapAndLightingAndDiffuseTexture:
	{
		glBindTexture(GL_TEXTURE_2D, m_texture);
		glActiveTexture(GL_TEXTURE1);
		glEnable(GL_TEXTURE_2D);
		[self setupEnvMap];

		glActiveTexture(GL_TEXTURE0);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
		glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
		glTexEnvi(GL_TEXTURE_ENV, GL_SRC0_RGB, GL_TEXTURE);
		glTexEnvi(GL_TEXTURE_ENV, GL_SRC1_RGB, GL_PRIMARY_COLOR);
		glTexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
		glTexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);

		glActiveTexture(GL_TEXTURE1);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
		glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_ADD);
		glTexEnvi(GL_TEXTURE_ENV, GL_SRC0_RGB, GL_TEXTURE);
		glTexEnvi(GL_TEXTURE_ENV, GL_SRC1_RGB, GL_PREVIOUS);
		glTexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
		glTexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);

		break;
	}

	case LightingMode::MaskedEnvMapAndLightingAndDiffuseTexture:
	{
		if (pass == 0)
		{
			glBindTexture(GL_TEXTURE_2D, m_texture);
			glActiveTexture(GL_TEXTURE1);
			glDisable(GL_TEXTURE_2D);		
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, m_envMask);

			const float gloss = 0.5f;
			const float glossFactor[] = {gloss, gloss, gloss, gloss};
			glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, glossFactor);
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
			glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
			glTexEnvi(GL_TEXTURE_ENV, GL_SRC0_RGB, GL_TEXTURE);
			glTexEnvi(GL_TEXTURE_ENV, GL_SRC1_RGB, GL_CONSTANT);
			glTexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
			glTexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);

			glActiveTexture(GL_TEXTURE1);
			glEnable(GL_TEXTURE_2D);
			[self setupEnvMap];

			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
			glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
			glTexEnvi(GL_TEXTURE_ENV, GL_SRC0_RGB, GL_TEXTURE);
			glTexEnvi(GL_TEXTURE_ENV, GL_SRC1_RGB, GL_PREVIOUS);
			glTexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
			glTexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);
		}
		break;
	}

	default:
		break;
	}

	glActiveTexture(GL_TEXTURE0);
}


- (void)drawView 
{    
    [EAGLContext setCurrentContext:context];
    
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
    glViewport(0, 0, backingWidth, backingHeight);
    
	const float HFovX = 0.2f;
	const float AspectRatio = 320/480.0;
	
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glFrustumf(-HFovX, HFovX, -HFovX/AspectRatio, HFovX/AspectRatio, 1.0f, 200.0f);
	
	static float i = 0;
	//++i;
	
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glRotatef(-90, 0, 0, 1.0f);
	glTranslatef(0,-1,-50);
    glRotatef(m_xAngle, 1.00, 0.0f, 0.0f);
    glRotatef(m_yAngle + 180 - i, 0, 1.0f, 0.0f);
    
	glEnable(GL_CULL_FACE);	
	glEnable(GL_DEPTH_TEST);
    glClearColor(0.2f, 0.2f, 0.3f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT| GL_DEPTH_BUFFER_BIT);
    
	[self setupLightingMode:0];
	[self setupGeometry:0];
	[self setupTexture:0];    
	glDrawElements(GL_TRIANGLES, m_mesh->m_indexCount, GL_UNSIGNED_SHORT, m_mesh->m_indices);	
    
	if (m_lightingMode == LightingMode::MaskedEnvMapAndLightingAndDiffuseTexture)
	{
		glDepthFunc(GL_EQUAL);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		
		[self setupLightingMode:1];
		[self setupGeometry:1];
		[self setupTexture:1];
		 
		glDrawElements(GL_TRIANGLES, m_mesh->m_indexCount, GL_UNSIGNED_SHORT, m_mesh->m_indices);	

		glDepthFunc(GL_LESS);
		glDisable(GL_BLEND);
	}

	
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
    [context presentRenderbuffer:GL_RENDERBUFFER_OES];
}


- (void)layoutSubviews {
    [EAGLContext setCurrentContext:context];
    [self destroyFramebuffer];
    [self createFramebuffer];
    [self drawView];
}


- (BOOL)createFramebuffer {
    
    glGenFramebuffersOES(1, &viewFramebuffer);
    glGenRenderbuffersOES(1, &viewRenderbuffer);
    
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
    [context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:(CAEAGLLayer*)self.layer];
    glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, viewRenderbuffer);
    
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);
    
    if (USE_DEPTH_BUFFER) {
        glGenRenderbuffersOES(1, &depthRenderbuffer);
        glBindRenderbufferOES(GL_RENDERBUFFER_OES, depthRenderbuffer);
        glRenderbufferStorageOES(GL_RENDERBUFFER_OES, GL_DEPTH_COMPONENT16_OES, backingWidth, backingHeight);
        glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER_OES, depthRenderbuffer);
    }
    
    if(glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES) {
        NSLog(@"failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
        return NO;
    }
    
    return YES;
}


- (void)destroyFramebuffer {
    
    glDeleteFramebuffersOES(1, &viewFramebuffer);
    viewFramebuffer = 0;
    glDeleteRenderbuffersOES(1, &viewRenderbuffer);
    viewRenderbuffer = 0;
    
    if(depthRenderbuffer) {
        glDeleteRenderbuffersOES(1, &depthRenderbuffer);
        depthRenderbuffer = 0;
    }
}


- (void)startAnimation {
    self.animationTimer = [NSTimer scheduledTimerWithTimeInterval:animationInterval target:self selector:@selector(drawView) userInfo:nil repeats:YES];
}


- (void)stopAnimation {
    self.animationTimer = nil;
}


- (void)setAnimationTimer:(NSTimer *)newTimer {
    [animationTimer invalidate];
    animationTimer = newTimer;
}


- (void)setAnimationInterval:(NSTimeInterval)interval {
    
    animationInterval = interval;
    if (animationTimer) {
        [self stopAnimation];
        [self startAnimation];
    }
}


- (void)dealloc {
    
    [self stopAnimation];
    
    if ([EAGLContext currentContext] == context) {
        [EAGLContext setCurrentContext:nil];
    }
    
	delete m_mesh;
    [context release];  
    [super dealloc];
}



- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	NSSet* allTouches = [event allTouches];
	if ([allTouches count] == 1)
	{
		const UITouch* touch = [allTouches anyObject];
		m_lastTouchPos = [touch locationInView:self];
	}
}


- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	NSSet* allTouches = [event allTouches];
	//NSLog(@"Touches moved: %d", [allTouches count]);
	if ([allTouches count] == 1)
	{
		const UITouch* touch = [allTouches anyObject];
		const CGPoint pos = [touch locationInView:self];
		m_yAngle += (pos.y - m_lastTouchPos.y);
		m_xAngle -= (pos.x - m_lastTouchPos.x);
		m_lastTouchPos = pos;
	}
}


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
}


- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
}



@end
