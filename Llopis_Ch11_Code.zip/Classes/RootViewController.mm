#import "RootViewController.h"
#include "EAGLView.h"

namespace
{
	const NSString* LightingModes[] =
	{
		@"Diffuse texture",
		@"Diffuse light and texture",
		@"Diffuse, specular light and texture",
		@"Environment map",
		@"Environment map, diffuse light, and texture",
		@"Masked env map, diffuse light, and texture",
	};

}


@implementation RootViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

- (void)viewDidLoad 
{
    [super viewDidLoad];

	m_uiView.transform = CGAffineTransformMakeRotation(M_PI/2);
	m_uiView.frame = CGRectMake(320-28,0,28, 480);	

	m_glView.animationInterval = 1.0 / 30.0;
	[m_glView startAnimation];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

- (IBAction)prevRenderingMode
{
	if (m_glView.m_lightingMode == LightingMode::DiffuseTexture)
		m_glView.m_lightingMode = (LightingMode::Enum)(LightingMode::Count - 1);
	else
		m_glView.m_lightingMode = (LightingMode::Enum)(m_glView.m_lightingMode - 1);
	m_modeLabel.text = LightingModes[m_glView.m_lightingMode];
}


- (IBAction)nextRenderingMode
{
	m_glView.m_lightingMode = (LightingMode::Enum)(m_glView.m_lightingMode + 1);
	if (m_glView.m_lightingMode == LightingMode::Count)
		m_glView.m_lightingMode = LightingMode::DiffuseTexture;
	m_modeLabel.text = LightingModes[m_glView.m_lightingMode];
}


@end
