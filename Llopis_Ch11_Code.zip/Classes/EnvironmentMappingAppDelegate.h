//
//  EnvironmentMappingAppDelegate.h
//  EnvironmentMapping
//
//  Created by Noel on 7/26/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RootViewController;

@interface EnvironmentMappingAppDelegate : NSObject <UIApplicationDelegate> {
    IBOutlet UIWindow* m_window;
	IBOutlet RootViewController* m_viewController;
}


@end

