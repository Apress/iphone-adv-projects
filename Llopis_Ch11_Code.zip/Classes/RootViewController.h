//
//  RootViewController.h
//  EnvironmentMapping
//
//  Created by Noel on 7/30/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EAGLView;


@interface RootViewController : UIViewController {
    IBOutlet EAGLView* m_glView;

	IBOutlet UIView* m_uiView;
	IBOutlet UILabel* m_modeLabel;	
}

- (IBAction)prevRenderingMode;
- (IBAction)nextRenderingMode;

@end
