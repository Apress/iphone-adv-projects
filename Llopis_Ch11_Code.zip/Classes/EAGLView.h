#import <UIKit/UIKit.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

struct Mesh;

namespace LightingMode
{
	enum Enum
	{
		DiffuseTexture,
		DiffuseLightingAndDiffuseTexture,
		DiffuseSpecularLightingAndDiffuseTexture,
		EnvMap,
		EnvMapAndLightingAndDiffuseTexture,
		MaskedEnvMapAndLightingAndDiffuseTexture,
		Count,
	};
}


@interface EAGLView : UIView {
    
@private
    /* The pixel dimensions of the backbuffer */
    GLint backingWidth;
    GLint backingHeight;
    
    EAGLContext *context;
    
    GLuint viewRenderbuffer, viewFramebuffer;
	GLuint depthRenderbuffer;
    
    NSTimer *animationTimer;
    NSTimeInterval animationInterval;
	CGPoint m_lastTouchPos;

	Mesh* m_mesh;
	uint m_texture;
	uint m_envMap;
	uint m_envMask;
	
	float m_xAngle;
	float m_yAngle;
	
	LightingMode::Enum m_lightingMode;
}

@property NSTimeInterval animationInterval;
@property LightingMode::Enum m_lightingMode;

- (void)startAnimation;
- (void)stopAnimation;
- (void)drawView;

@end
