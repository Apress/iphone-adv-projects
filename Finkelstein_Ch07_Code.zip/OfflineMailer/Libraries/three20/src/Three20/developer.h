/*
 * This file contains developer-specific preprocessor definitions.  It exists mostly to prevent
 * Joe from continually checking in debugging code.  If you modify this file, run this command
 * to tell git to ignore your changes:
 *
 *    git update-index --assume-unchanged src/Three20/developer.h
 */
 
//#define JOE 1
//
//#define TEST_SECTION 3
//#define TEST_ROW 1
