#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSDate (TTCategory)

+ (NSDate*)dateWithToday;

- (NSDate*)dateAtMidnight;

@end
