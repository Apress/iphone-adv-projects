#import "Three20/TTGlobal.h"

/**
 * A utility view that will cause all of its ancestors to stop clipping, ensuring that
 * nothing obscures any of part of this view and its contents.
 */
@interface TTUnclippedView : UIView
@end
