#import "Three20/TTButton.h"

@interface TTThumbView : TTButton

@property(nonatomic,copy) NSString* thumbURL;

@end
