#import "Three20/TTView.h"

@interface TTTableHeaderView : TTView {
  UILabel* _label;
}

- (id)initWithTitle:(NSString*)title;

@end
