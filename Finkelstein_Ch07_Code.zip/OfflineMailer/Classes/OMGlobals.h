#define kMessageSentSuccessfully @"MessageSentSuccessFully"
#define kMessageSentFailure @"MessageSentFailure"
#define kMessageQueuedSuccessfully @"MessageQueuedSuccessfully"

