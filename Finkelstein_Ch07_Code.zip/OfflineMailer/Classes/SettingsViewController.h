//
//  SettingsViewController.h
//  OfflineMailer
//
//  Created by Steve Finkelstein on 4/9/09.
//  Copyright __InsertCompanyNameHere__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SettingsViewController : UIViewController {

}

@end
