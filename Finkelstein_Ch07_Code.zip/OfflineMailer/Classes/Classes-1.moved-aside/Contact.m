// 
//  Contact.m
//  OfflineMailer
//
//  Created by Steve Finkelstein on 8/2/09.
//  Copyright 2009 __Insert Company Name Here__. All rights reserved.
//

#import "Contact.h"


@implementation Contact 

@dynamic contactID;
@dynamic firstName;
@dynamic lastName;

@end
