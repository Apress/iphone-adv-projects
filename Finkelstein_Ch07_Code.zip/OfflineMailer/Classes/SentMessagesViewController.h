//
//  SentMessagesViewController.h
//  OfflineMailer
//
//  Created by Steve Finkelstein on 6/13/09.
//  Copyright 2009 __Insert Company Name Here__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SentMessagesViewController : UITableViewController {

}

@end
