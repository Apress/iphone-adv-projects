// 
//  Message.m
//  OfflineMailer
//
//  Created by Steve Finkelstein on 8/4/09.
//  Copyright 2009 __Insert Company Name Here__. All rights reserved.
//

#import "Message.h"


@implementation Message 

@dynamic subject;
@dynamic dateSent;
@dynamic messageID;
@dynamic to;
@dynamic body;

@end
