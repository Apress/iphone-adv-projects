//
//  TestCPPClass.h
//  MemoryBugs
//
//  Created by Owen Goss on 2009/04/17.
//  Copyright 2009 Streaming Colour Studios. All rights reserved.
//

class TestCPPClass
{
public:
	// Constructor
	TestCPPClass();
	
	// Destructor
	~TestCPPClass();
	
	void DoSomething();
	
	void ForceBufferOverrun();
	
private:
	int mSomeNum;
	int mOverrunMe[16];
	int mIGetStomped;
};
