//
//  TestClass.h
//  MemoryBugs
//
//  Created by Owen Goss on 2009/04/17.
//  Copyright 2009 Streaming Colour Studios. All rights reserved.
//

#import <Foundation/Foundation.h>

// This is our dummy class
@interface TestClass : NSObject {
	NSString* myString;
}

@property (nonatomic, retain) NSString* myString;

- (void)doNothing;

@end
