//
//  MemoryBugsViewController.m
//  MemoryBugs
//
//  Created by Owen Goss on 13/03/09.
//  Copyright Streaming Colour Studios 2009. All rights reserved.
//

#import "MemoryBugsViewController.h"
#import "TestClass.h"
#import "TestCPPClass.h"

@implementation MemoryBugsViewController

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	// Test case for double release - malloc_error_break
	/*
	NSDate* date = [NSDate date];
	[date release];
	[date release];
	 */
	
	// Test case for NSZombie
	/*
	TestClass* testInstance = [TestClass alloc];
	[testInstance release];
	NSLog(@"Test Class's myString = %@", testInstance.myString);
	 */
	
	// Text case for Enable Guard Malloc - delete and use
	/*
	mTestCpp = new TestCPPClass();
	delete mTestCpp;
	mTestCpp->DoSomething();
	 */
	
	// Test case for buffer overrun
	/*
	mTestCpp = new TestCPPClass();
	mTestCpp->ForceBufferOverrun();
	delete mTestCpp;
	 */
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}

@end
