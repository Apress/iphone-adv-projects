//
//  MemoryBugsViewController.h
//  MemoryBugs
//
//  Created by Owen Goss on 13/03/09.
//  Copyright Streaming Colour Studios 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MemoryBugsViewController : UIViewController {
	struct TestCPPClass* mTestCpp;
}

@end

