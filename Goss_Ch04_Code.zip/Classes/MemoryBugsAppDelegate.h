//
//  MemoryBugsAppDelegate.h
//  MemoryBugs
//
//  Created by Owen Goss on 13/03/09.
//  Copyright Streaming Colour Studios 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MemoryBugsViewController;

@interface MemoryBugsAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MemoryBugsViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MemoryBugsViewController *viewController;

@end

