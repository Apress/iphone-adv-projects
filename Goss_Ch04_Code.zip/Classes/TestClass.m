//
//  TestClass.m
//  MemoryBugs
//
//  Created by Owen Goss on 2009/04/17.
//  Copyright 2009 Streaming Colour Studios. All rights reserved.
//

#import "TestClass.h"


@implementation TestClass

@synthesize myString;

- (void)doNothing
{
	// Do nothing
}

- (void)dealloc
{
	[myString release];
	[super dealloc];
}

@end
