//
//  MyDebug.h
//
//  Created by Owen Goss.
//  Copyright 2008 Streaming Colour Studios. All rights reserved.
//


#if defined(APP_STORE_FINAL)
	#define MY_ASSERT(STATEMENT) do { (void)sizeof(STATEMENT); } while(0)
#else
	#define MY_ASSERT(STATEMENT) do { assert(STATEMENT); } while(0)
#endif


#if defined(APP_STORE_FINAL)
	#define MY_LOG(format, ...)
#else
	// MY_LOG takes a c-string as a parameter
	#define MY_LOG(format, ...) CFShow([NSString stringWithFormat:[NSString stringWithUTF8String:format], ## __VA_ARGS__]);
	// MY_LOG takes an NSString as a parameter
	//#define MY_LOG(format, ...) CFShow([NSString stringWithFormat:format, ## __VA_ARGS__]);
#endif

