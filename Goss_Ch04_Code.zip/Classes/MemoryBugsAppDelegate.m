//
//  MemoryBugsAppDelegate.m
//  MemoryBugs
//
//  Created by Owen Goss on 13/03/09.
//  Copyright Streaming Colour Studios 2009. All rights reserved.
//

#import "MemoryBugsAppDelegate.h"
#import "MemoryBugsViewController.h"

@implementation MemoryBugsAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
