//
//  TestCPPClass.mm
//  MemoryBugs
//
//  Created by Owen Goss on 2009/04/17.
//  Copyright 2009 Streaming Colour Studios. All rights reserved.
//

#import "TestCPPClass.h"

TestCPPClass::TestCPPClass()
: mSomeNum(0)
, mIGetStomped(0)
{
	mIGetStomped = -1;
}

TestCPPClass::~TestCPPClass()
{
}

void TestCPPClass::DoSomething()
{
	++mSomeNum;
}

void TestCPPClass::ForceBufferOverrun()
{
	// Write one too many ints into the array
	for (int i = 0; i < 17; i++)
	{
		mOverrunMe[i] = i;
	}
	
	// The loop above will have written the value "16" into mIGetStomped,
	// since it lies directly after the array in memory.
	NSLog(@"mIGetStomped = %d", mIGetStomped);
}


