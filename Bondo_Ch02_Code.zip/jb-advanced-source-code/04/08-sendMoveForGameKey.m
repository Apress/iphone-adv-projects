- (void)sendMove:(NSString *)move forGameKey:(NSString *)key
{
  NSString            *urlStr;
  NSMutableURLRequest *request; 
  NSURLConnection     *connection;
  
  urlStr = [NSString stringWithFormat:
    @"http://localhost:8080/game?action=move&move=%@&key=%@", move, key];
  request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]
    cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData 
    timeoutInterval:60.0];
  [request setHTTPMethod:@"PUT"];
  connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  
  if (!connection) {
    // Deal with the error
  } else
    receivedData_ = [[NSMutableData alloc] initWithCapacity:500];
}
