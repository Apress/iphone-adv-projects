- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
  [receivedData_ appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
  [connection release];
  
  NSDictionary *response;
  NSString     *errorString = nil;
  
  response = [NSPropertyListSerialization propertyListFromData:receivedData_ 
    mutabilityOption:NSPropertyListImmutable format:NULL
    errorDescription:&errorString];
  [receivedData_ release];
  
  if (!response) {
    // Handle the error
    [errorString release];
    return;
  }
  // Do something with response
}

- (void)connection:(NSURLConnection *)connection 
didReceiveResponse:(NSURLResponse *)response
{
  [receivedData_ setLength:0];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
  [connection release];
  [receivedData_ release];
  // Notify about the error
}
