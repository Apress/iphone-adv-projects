def put (self):
  game = Game.get (self.request.get ('key'))
  game.moves.append (self.request.get ('move'))
  game.put ()
  template_values = {'game': game, 'success': True}
  path = os.path.join (os.path.dirname (__file__), 'move.plist')
  self.response.out.write (template.render (path, template_values))
