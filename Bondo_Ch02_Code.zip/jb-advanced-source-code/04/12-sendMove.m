- (void)sendMove:(id)sender
{
  NSString *move = 
    [NSString stringWithFormat:@"%c%i", random() % 8 + 97, random() % 8 + 1];
  [self sendMove:move forGameKey:@"<the game key>"];
}
