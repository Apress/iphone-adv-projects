- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
  if (![[url scheme] isEqualToString:@"chess"])
    return NO;
  
  // chess://localhost:8080/game?action=accept&email=me@example.com&key=
  
  NSString     *userID;
  NSString     *serverURLStr;
  NSURL        *serverURL;
  NSDictionary *game;
  
  userID       = [[NSUserDefaults standardUserDefaults] stringForKey:@"userID"];
  serverURLStr = [NSString stringWithFormat:@"http://%@%@?%@&userid=%@", 
                   [url host], [url path], [url query], userID ? userID : @""];
  serverURL    = [NSURL URLWithString:serverURLStr];
  game         = [NSDictionary dictionaryWithContentsOfURL:serverURL];
  if (!game) {
    // Deal with the error
  }
  return YES;
}
