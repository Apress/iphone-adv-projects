def get (self):
  game = Game.get (self.request.get ('key'))
  template_values = {'game': game}
  path = os.path.join (os.path.dirname (__file__), 'game.plist')
  self.response.out.write (template.render (path, template_values))
  
from google.appengine.ext.webapp import template
import os
