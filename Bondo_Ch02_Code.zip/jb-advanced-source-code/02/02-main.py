from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app

class GameController (webapp.RequestHandler):
  def get (self):
    opponent = self.request.get ('opponent')
    self.response.headers ['Content-Type'] = 'text/plain'
    self.response.out.write ('Looks like you want to invite ' + opponent)

application = webapp.WSGIApplication (
  [('/', GameController)],
  debug=True)

def main():
  run_wsgi_app (application)

if __name__ == "__main__":
  main()
