from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app
from google.appengine.ext import db
from google.appengine.api import mail

class Game (db.Model):
  inviter = db.StringProperty ()
  invitee = db.StringProperty ()
  created = db.DateTimeProperty (auto_now_add = True)
  moves = db.StringListProperty ()

class GameController (webapp.RequestHandler):
  def post (self):
    game = Game ()
    game.inviter = self.request.get ('inviter')
    game.invitee = self.request.get ('invitee')
    game.put ()
    mail.send_mail (sender = game.inviter,
      to = game.invitee,
      subject = "Hey, let’s play one helluva game of chess!",
      body = "Click here: chess://domain.com/game?action=accept&email=%s&game=%s" %
                                                  (game.invitee, str (game.key ()))
    )
    self.redirect ('/games')
  def get (self):
    self.response.out.write ('<html><body>')
    self.response.out.write ('<p>Your games:</p><ul>')
    games = db.GqlQuery ("SELECT * FROM Game ORDER BY created DESC LIMIT 10")
    for game in games:
      self.response.out.write ('<li>%s vs. %s (%s)</li>' % 
                                   (game.inviter, game.invitee, str (game.key ())))
    self.response.out.write ('</ul></body></html>')
    
class EntryForm (webapp.RequestHandler):
  def get (self):
    self.response.out.write ("""<html><body>
    <form action="/game" method="post">
      <div>Opponent: <input type="text" name="invitee"/></div>
      <div>You: <input type="text" name="inviter"/></div>
      <div><input type="submit" value="Invite!"/></div>
    </form>
    </body></html>""")
    
application = webapp.WSGIApplication ([
  ('/', EntryForm),
  ('/games', GameController),
  ('/game', GameController),
  ], debug=True)

def main ():
  run_wsgi_app (application)

if __name__ == "__main__":
  main ()
