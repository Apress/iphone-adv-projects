//
//  GroceryItem.m
//  GroceryList
//
//  Created by Dylan Bruzenak on 6/18/09.
//  Copyright 2009 Dylan Bruzenak. All rights reserved.
//

#import "GroceryItem.h"


@implementation GroceryItem
@synthesize name, number, price;

- (void) dealloc
{
	[name release];
	[number release];
	[price release];
	[super dealloc];
}

@end
