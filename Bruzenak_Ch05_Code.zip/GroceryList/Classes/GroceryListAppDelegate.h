//
//  GroceryListAppDelegate.h
//  GroceryList
//
//  Created by Dylan Bruzenak on 6/16/09.
//  Copyright Dylan Bruzenak 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ISDatabase;

@interface GroceryListAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    UINavigationController *navigationController;
	ISDatabase *database;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@property (nonatomic, retain) ISDatabase *database;

@end

