//
//  RootViewController.h
//  GroceryList
//
//  Created by Dylan Bruzenak on 6/16/09.
//  Copyright Dylan Bruzenak 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
	NSArray *results;
}

@property (nonatomic, retain) NSArray *results;
@end
