//
//  ExampleDatabase.m
//  GroceryList
//
//  Created by Dylan Bruzenak on 6/18/09.
//  Copyright 2009 Dylan Bruzenak. All rights reserved.
//

#import "ExampleDatabase.h"
#import "ISModel.h"

@implementation ExampleDatabase

#pragma mark -
#pragma mark Application Properties

- (void) updateApplicationProperty: (NSString *) propertyName value: (id) value
{
	[self executeSqlWithParameters: @"update ApplicationProperties set value = ? where name = ?", value, propertyName, nil];
}

- (id) getApplicationProperty: (NSString *) propertyName
{
	NSArray *rows = [self executeSqlWithParameters: @"select value from ApplicationProperties where name = ?", propertyName, nil];
	
	if([rows count] == 0)
	{
		return nil;
	}
	
	id object = [[rows lastObject] objectForKey:@"value"];
	if([object isKindOfClass: [NSString class]])
	{
		object = [NSNumber numberWithInteger:[(NSString *)object integerValue]];
	}
	return object;
}

- (NSUInteger) databaseVersion
{
	return [[self getApplicationProperty:@"databaseVersion"] unsignedIntegerValue];
}

- (void) setDatabaseVersion: (NSUInteger) newVersionNumber
{
	return [self updateApplicationProperty:@"databaseVersion" value:[NSNumber numberWithUnsignedInteger: newVersionNumber]];
}

#pragma mark -
#pragma mark Migrations

- (void) createApplicationPropertiesTable
{
	[self executeSql:@"create table ApplicationProperties (primaryKey integer primary key autoincrement, name text, value integer)"];
	[self executeSql:@"insert into ApplicationProperties (name, value) values('databaseVersion', 1)"];
}

- (void) createGroceryItemTable
{
	[self executeSql:@"create table GroceryItem(primaryKey integer primary key autoincrement, name text NOT NULL, number integer NOT NULL)"];
	[self executeSql:@"insert into GroceryItem (name, number) values('apples', 5)"];
	[self executeSql:@"insert into GroceryItem (name, number) values('oranges', 3)"];
}

- (void) addPriceToGroceryItemTable
{
	[self executeSql: @"alter table GroceryItem add price real"];
}

- (void) runMigrations
{
	[self beginTransaction];
	
	NSArray *tableNames = [self tableNames];
	
	if(![tableNames containsObject:@"ApplicationProperties"])
	{
		[self createApplicationPropertiesTable];
		[self createGroceryItemTable];
		//add any other version 1 schema creation code here
	}
	
	if([self databaseVersion] < 2)
	{
		[self setDatabaseVersion: 2];
		[self addPriceToGroceryItemTable];
	}
	[self commit];
}

- (id) initWithMigrations
{
	if(self = [super initWithFileName:@"Example.sqlite"])
	{
		[self runMigrations];
		[ISModel setDatabase:self];
	}
	
	return self;
}

@end
