//
//  GroceryListAppDelegate.m
//  GroceryList
//
//  Created by Dylan Bruzenak on 6/16/09.
//  Copyright Dylan Bruzenak 2009. All rights reserved.
//

#import "GroceryListAppDelegate.h"
#import "RootViewController.h"
#import "ExampleDatabase.h"
#import "GroceryItem.h"

@implementation GroceryListAppDelegate

@synthesize window;
@synthesize navigationController;
@synthesize database;

- (void)applicationDidFinishLaunching:(UIApplication *)application {
	database = [[[ExampleDatabase alloc] initWithMigrations] autorelease];
	
	NSArray *results = [GroceryItem findByColumn:@"name" value:@"Bananas"];
	
	if([results count] < 1)
	{
		GroceryItem *bananas = [[[GroceryItem alloc] init] autorelease];
		bananas.name = @"Bananas";
		bananas.number = [NSNumber numberWithInt: 10];
		[bananas save];
	}
	
	// Configure and show the window
	[window addSubview:[navigationController view]];
	[window makeKeyAndVisible];
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Save data if appropriate
}


- (void)dealloc {
	[database release];
	[navigationController release];
	[window release];
	[super dealloc];
}

@end
