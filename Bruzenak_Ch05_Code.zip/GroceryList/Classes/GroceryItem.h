//
//  GroceryItem.h
//  GroceryList
//
//  Created by Dylan Bruzenak on 6/18/09.
//  Copyright 2009 Dylan Bruzenak. All rights reserved.
//

#import "ISModel.h"


@interface GroceryItem : ISModel {
	NSString *name;
	NSNumber *number;
	NSNumber *price;
}

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSNumber *number;
@property (nonatomic, retain) NSNumber *price;
@end
