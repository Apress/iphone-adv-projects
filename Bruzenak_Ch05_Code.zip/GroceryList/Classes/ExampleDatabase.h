//
//  ExampleDatabase.h
//  GroceryList
//
//  Created by Dylan Bruzenak on 6/18/09.
//  Copyright 2009 Dylan Bruzenak. All rights reserved.
//

#import "ISDatabase.h"


@interface ExampleDatabase : ISDatabase {

}

- (id) initWithMigrations;
@end
