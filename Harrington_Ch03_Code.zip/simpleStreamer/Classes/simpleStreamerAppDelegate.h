//
//  simpleStreamerAppDelegate.h
//  simpleStreamer
//
//  Created by Tom Harrington on 5/27/09.
//  Copyright Atomic Bird, LLC 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class simpleStreamerViewController;

@interface simpleStreamerAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    simpleStreamerViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet simpleStreamerViewController *viewController;

@end

