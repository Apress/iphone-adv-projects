//
//  SimpleStreamer.m
//  simpleStreamer
//
//  Created by Tom Harrington on 5/27/09.
//  Copyright 2009 Atomic Bird, LLC. All rights reserved.
//

#import "SimpleStreamer.h"

@interface SimpleStreamer (private)
- (void)startQueue;
@end

void postPlayCallback (void *aqData, AudioQueueRef inAQ, AudioQueueBufferRef  inBuffer)
{
    SimpleStreamer *self = (SimpleStreamer *)aqData;
    PlayQueueData_t *currentBufferData = NULL;
    
    NSLog(@"Handling output buffer");
    
    // Find the playQueueDataRecs entry corresponding to inBuffer.
    for (int i=0; i<kNumAQBufs; i++) {
        if (self.playQueueDataRecs[i].buffer == inBuffer) {
            currentBufferData = &(self.playQueueDataRecs[i]);
            break;
        }
    }
    
    if (currentBufferData != NULL) {
        // Mark the buffer as being available, so it'll be available for new audio data.
        NSCondition *queuedCondition = (NSCondition *)currentBufferData->queuedCondition;
		NSLog(@"Locking condition");
        [queuedCondition lock];
        currentBufferData->inUse = NO;
        // Reset the packet and byte count on the buffer.
        currentBufferData->packetCount = currentBufferData->bytesFilled = 0;
        // Signal the condition in case enqueueCurrentBuffer is waiting on it.
		NSLog(@"Signalling condition");
        [queuedCondition signal];
        [queuedCondition unlock];
    }
}

void propertyListenerCallback (void *inClientData, AudioFileStreamID inAudioFileStream, AudioFileStreamPropertyID inPropertyID, UInt32 *ioFlags)
{
    SimpleStreamer *self = (SimpleStreamer *)inClientData;
    OSStatus err = noErr;
    UInt32 propertySize;
    
    if (inPropertyID == kAudioFileStreamProperty_ReadyToProducePackets) {
        // The stream is ready to produce audio packets
        
        // Get the audio format
        AudioStreamBasicDescription dataFormat;
        propertySize = sizeof(dataFormat);
        err = AudioFileStreamGetProperty(inAudioFileStream, kAudioFileStreamProperty_DataFormat, &propertySize, &dataFormat);
        
        // Create the play queue
        AudioQueueRef playQueue;
        err = AudioQueueNewOutput(&dataFormat, postPlayCallback, self, NULL, kCFRunLoopCommonModes, 0, &playQueue);
        [self setPlayQueue:playQueue];
        
        // Set up audio buffer structures
        for (int i=0; i<kNumAQBufs; i++) {
            self.playQueueDataRecs[i].queuedCondition = [[NSCondition alloc] init];
            err = AudioQueueAllocateBuffer(playQueue, kAQBufSize, &(self.playQueueDataRecs[i].buffer));
            if (err != noErr) {
                NSLog(@"Failed to allocate buffer: %d", err);
            }
        }
        self.currentBufferIndex = 0;
        
        // Lock the initial buffer, which is where we'll start writing data.
        NSCondition *queuedCondition = (NSCondition *)self.playQueueDataRecs[0].queuedCondition;
		NSLog(@"Locking condition");
        [queuedCondition lock];
        self.playQueueDataRecs[0].inUse = YES;
		NSLog(@"Unocking condition");
        [queuedCondition unlock];
        
        // Get magic cookie (for compressed formats like MPEG 4 AAC) from the file stream and set it on the audio queue
        err = AudioFileStreamGetPropertyInfo(inAudioFileStream, kAudioFileStreamProperty_MagicCookieData, &propertySize, NULL);
        void *magicCookie = calloc(1, propertySize);
        err = AudioFileStreamGetProperty(inAudioFileStream, kAudioFileStreamProperty_MagicCookieData, &propertySize, magicCookie);
        if (err == noErr) {
            err = AudioQueueSetProperty(playQueue, kAudioFileStreamProperty_MagicCookieData, magicCookie, propertySize);
        }
        free(magicCookie);
    }
}

void enqueueCurrentBuffer(SimpleStreamer *self)
{
    OSStatus err = noErr;
    
    @synchronized(self) {
        if ((self.queueStarted == YES) && (self.queueRunning == NO)) {
            // If the queue has stopped, don't enqueue any more data.
            NSLog(@"bailing out of enqueueCurrentBuffer");
            return;
        }
    }
    
    NSLog(@"Enqueueing %d bytes", self.playQueueDataRecs[self.currentBufferIndex].bytesFilled);
    
    // Mark the current buffer as "in use".
    self.playQueueDataRecs[self.currentBufferIndex].inUse = YES;
    // Set the data size of the buffer.
    AudioQueueBufferRef fillBuf = self.playQueueDataRecs[self.currentBufferIndex].buffer;
    fillBuf->mAudioDataByteSize = self.playQueueDataRecs[self.currentBufferIndex].bytesFilled;
    // Add the buffer to the queue
    err = AudioQueueEnqueueBuffer([self playQueue], fillBuf, self.playQueueDataRecs[self.currentBufferIndex].packetCount, self.playQueueDataRecs[self.currentBufferIndex].packetDescriptors);
    if (err) {
        // Could not enqueue buffer
        NSLog(@"Could not enqueue buffer");
        return;
    }
    
    // Start the playback queue, if it's not running.
    [self startQueue];
    
    // Go to the next buffer
    self.currentBufferIndex++;
    if (self.currentBufferIndex >= kNumAQBufs) {
        self.currentBufferIndex = 0;
    }
    
    // If the new current buffer is in use, wait for it to be returned to the pool.
    NSCondition *queuedCondition = (NSCondition *)self.playQueueDataRecs[self.currentBufferIndex].queuedCondition;
	NSLog(@"Locking condition");
    [queuedCondition lock];
    @synchronized(self) {
        if (self.queueStarted && (!self.queueRunning)) {
            // Don't wait on the buffer if the queue has stopped.
            NSLog(@"bailing out of enqueueCurrentBuffer (2)");
            return;
        }
    }
    while (self.playQueueDataRecs[self.currentBufferIndex].inUse) {
        NSLog(@"Waiting on in-use buffer");
        [queuedCondition wait];
    }
    [queuedCondition unlock];
}

void audioDataCallback (void *inClientData, UInt32 inNumberBytes, UInt32 inNumberPackets, const void *inInputData, AudioStreamPacketDescription *inPacketDescriptions)
{
    NSLog(@"Got audio data in callback: %d bytes, %d packets", inNumberBytes, inNumberPackets);
    
    SimpleStreamer *self = (SimpleStreamer *)inClientData;
    
    // Run through the incoming packets.
    for (int i=0; i<inNumberPackets; i++) {
        @synchronized(self) {
            if (self.queueStarted && (!self.queueRunning)) {
                // Stop if the queue is not running.
                NSLog(@"bailing out of audioDataCallback");
                return;
            }
        }
        
        // Get size and offset of the current packet's data
        SInt64 packetOffset = inPacketDescriptions[i].mStartOffset;
        SInt64 packetSize = inPacketDescriptions[i].mDataByteSize;
        
        // See if there's enough byte space left in the current buffer.
        size_t bufSpaceRemaining = kAQBufSize - self.playQueueDataRecs[self.currentBufferIndex].bytesFilled;
        if (bufSpaceRemaining < packetSize) {
            // Not enough space in the current buffer, so enqueue it and go to the next buffer.
            enqueueCurrentBuffer(self);
        }
        
        // Copy data to the audio queue buffer
        AudioQueueBufferRef fillBuf = self.playQueueDataRecs[self.currentBufferIndex].buffer;
        memcpy((char*)fillBuf->mAudioData + self.playQueueDataRecs[self.currentBufferIndex].bytesFilled,
               (const char *)inInputData + packetOffset, packetSize);
        // Fill out packet description
        self.playQueueDataRecs[self.currentBufferIndex].packetDescriptors[self.playQueueDataRecs[self.currentBufferIndex].packetCount] = inPacketDescriptions[i];
        self.playQueueDataRecs[self.currentBufferIndex].packetDescriptors[self.playQueueDataRecs[self.currentBufferIndex].packetCount].mStartOffset = self.playQueueDataRecs[self.currentBufferIndex].bytesFilled;
        // Keep track of bytes and packets filled in the current buffer
        self.playQueueDataRecs[self.currentBufferIndex].bytesFilled += packetSize;
        self.playQueueDataRecs[self.currentBufferIndex].packetCount += 1;
        
        // See if we've run out of packet space
        size_t packetDescriptorsRemaining = kAQMaxPacketDescs - self.playQueueDataRecs[self.currentBufferIndex].packetCount;
        if (packetDescriptorsRemaining == 0) {
            // No more packet descriptors in the current buffer, so add it to the queue.
            enqueueCurrentBuffer(self);
        }
    }
}


@implementation SimpleStreamer

@synthesize url;
//@synthesize dataFormat;
@synthesize playQueue;
@synthesize queueRunning;
@synthesize queueStarted;
@synthesize currentBufferIndex;
@synthesize playQueueDataRecs;
@synthesize fileTypeHint;

+ (void)initialize
{
    AudioSessionInitialize(NULL, NULL, NULL, NULL);
}

- (id)initWithURL:(NSURL *)audioUrl
{
    if (self = [super init]) {
        url = [audioUrl retain];
        playQueueDataRecs = (PlayQueueData_t *)malloc(sizeof(PlayQueueData_t) * kNumAQBufs);
    }
    return self;
}

- (void)dealloc
{
    [url release];
    free(playQueueDataRecs);
    [super dealloc];
}

- (void)play
{
    // Create audio stream using callback functions.
    // Third argument is an optional hint to file type.
    AudioFileStreamOpen(self, propertyListenerCallback, audioDataCallback, self.fileTypeHint, &myAudioStream);
    
    // Create the network connection
    NSURLRequest *networkRequest = [NSURLRequest requestWithURL:self.url];
    networkConnection = [[NSURLConnection alloc] initWithRequest:networkRequest delegate:self];
}

- (void)stop
{
    [networkConnection cancel];
    [networkConnection release];
    AudioQueueStop(playQueue, true);
    AudioFileStreamClose(myAudioStream);
    AudioQueueDispose(playQueue, YES);
}

// Start the audio queue, if it's not already playing
- (void)startQueue
{
    if (!queueStarted) {
        AudioQueueStart(playQueue, NULL);
        @synchronized(self) {
            queueStarted = queueRunning = YES;
        }
    }
}

// NSURLConnection delegate method
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"Received %d bytes", [data length]);
    
    // Pass incoming bytes to audio stream parser.
    AudioFileStreamParseBytes(myAudioStream, [data length], [data bytes], 0);
}

// NSURLConnection delegate method
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"Connection failed: %@", error);
}

// NSURLConnection delegate method
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"Connection finished loading");
}

@end
