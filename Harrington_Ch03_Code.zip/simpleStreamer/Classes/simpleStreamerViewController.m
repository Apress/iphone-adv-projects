//
//  simpleStreamerViewController.m
//  simpleStreamer
//
//  Created by Tom Harrington on 5/27/09.
//  Copyright Atomic Bird, LLC 2009. All rights reserved.
//

#import "simpleStreamerViewController.h"

NSString *urlString = @"http://192.168.0.4/test.mp3";

@implementation simpleStreamerViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (IBAction)play:(id)sender
{
    NSURL *url = [NSURL URLWithString:urlString];
    if (streamer == nil) {
        streamer = [[SimpleStreamer alloc] initWithURL:url];
    }
    streamer.fileTypeHint = kAudioFileMP3Type;
    [streamer play];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}

@end
