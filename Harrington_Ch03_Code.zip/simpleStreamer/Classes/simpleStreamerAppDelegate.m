//
//  simpleStreamerAppDelegate.m
//  simpleStreamer
//
//  Created by Tom Harrington on 5/27/09.
//  Copyright Atomic Bird, LLC 2009. All rights reserved.
//

#import "simpleStreamerAppDelegate.h"
#import "simpleStreamerViewController.h"

@implementation simpleStreamerAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
