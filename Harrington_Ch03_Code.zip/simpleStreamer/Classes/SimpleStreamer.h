//
//  SimpleStreamer.h
//  simpleStreamer
//
//  Created by Tom Harrington on 5/27/09.
//  Copyright 2009 Atomic Bird, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>

// Number of audio queue buffers we allocate
#define kNumAQBufs 3
// Number of packet descriptions in our array
#define kAQMaxPacketDescs 512
// Use a hard-coded buffer size.
#define kAQBufSize 1048576

// Data structure containing an audio queue buffer as well as its associated data.
typedef struct PlayQueueData {
    AudioQueueBufferRef buffer;
    NSCondition *queuedCondition;
    UInt32 packetCount;
    AudioStreamPacketDescription packetDescriptors[kAQMaxPacketDescs];
    size_t bytesFilled;
    BOOL inUse;
} PlayQueueData_t;


@interface SimpleStreamer : NSObject {
    NSURL *url;
    NSURLConnection *networkConnection;
    
    AudioFileStreamID myAudioStream;
    AudioQueueRef playQueue;
	AudioFileTypeID fileTypeHint;
    
    BOOL queueStarted;
    BOOL queueRunning;
    
    PlayQueueData_t *playQueueDataRecs;
    unsigned int currentBufferIndex;
}

@property (readonly) NSURL *url;
@property (readwrite) AudioQueueRef playQueue;
@property (readwrite) AudioFileTypeID fileTypeHint;
@property (readwrite) BOOL queueRunning;
@property (readwrite) BOOL queueStarted;
@property (readwrite) unsigned int currentBufferIndex;
@property (readwrite) PlayQueueData_t *playQueueDataRecs;


- (id)initWithURL:(NSURL *)url;
- (void)play;
- (void)stop;

@end
