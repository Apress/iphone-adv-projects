//
//  simpleStreamerViewController.h
//  simpleStreamer
//
//  Created by Tom Harrington on 5/27/09.
//  Copyright Atomic Bird, LLC 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SimpleStreamer.h"

@interface simpleStreamerViewController : UIViewController {
    SimpleStreamer *streamer;
}

- (IBAction)play:(id)sender;

@end

