//
//  NetworkDiscovery.h
//  Discover
//
//  Created by Florian Pflug on 13.05.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#include <CoreFoundation/CoreFoundation.h>

#import <Foundation/Foundation.h>

@interface NetworkDiscovery : NSObject {
	NSMutableDictionary* peers;

	int socket_bsd;
	CFSocketRef socket_cf;
	CFRunLoopSourceRef socket_runloopsource;

	NSTimer* timer;
	BOOL previousHelloResult;
}

@property (readonly) NSMutableDictionary* peers;

+ (NSArray*)interfaceNamesAddresses;
+ (short) interfaceFlags:(NSString*)interface;
+ (void)sockaddr_in:(struct sockaddr_in*)sa_in setAddress:(in_addr_t)addr port:(in_port_t)port;

+ (void)setup;
+ (NetworkDiscovery*) instance;
+ (void)shutdown;

- (id)init;
- (void)stop;
- (void)dealloc;

- (void)onTimer:(NSTimer*)timer;
- (void)onDatagram:(NSData*)data fromAddress:(in_addr_t)srcAddr port:(in_port_t)srcPort;

- (BOOL)sendData:(NSData*)data toAddress:(in_addr_t)dstAddr port:(in_port_t)dstPort;
- (BOOL)multicastData:(NSData*)data toGroup:(in_addr_t)mcGroup port:(in_port_t)dstPort onInterfaceWithAddress:(in_addr_t)ifaceAddr;
- (BOOL)multicastData:(NSData*)data toGroup:(in_addr_t)mcGroup port:(in_port_t)dstPort;

@end
