//
//  DiscoverAppDelegate.h
//  Discover
//
//  Created by Florian Pflug on 13.05.09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DiscoverViewController;

@interface DiscoverAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    DiscoverViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet DiscoverViewController *viewController;

@end

