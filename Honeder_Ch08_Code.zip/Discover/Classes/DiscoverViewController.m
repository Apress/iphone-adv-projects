//
//  DiscoverViewController.m
//  Discover
//
//  Created by Florian Pflug on 13.05.09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "DiscoverViewController.h"

@implementation DiscoverViewController

@synthesize tableViewController;

- (id) init {
	if ((self = [super init])) {
		[self setup];
	}
	
	return self;
}

- (id)initWithCoder:(NSCoder *)decoder {
	if ((self = [super initWithCoder:decoder]))
		[self setup];
	return self;
}

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]))
		[self setup];
	return self;
}

- (void) setup {
	tableViewController = nil;
}

- (void) viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	[self.tableViewController viewWillAppear:animated];
}

- (void) viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
	[self.tableViewController viewDidAppear:animated];
}

- (void) viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	[self.tableViewController viewWillDisappear:animated];
}

- (void) viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	[self.tableViewController viewDidDisappear:animated];
}

- (void)dealloc {
	[tableViewController release];
    [super dealloc];
}

@end
