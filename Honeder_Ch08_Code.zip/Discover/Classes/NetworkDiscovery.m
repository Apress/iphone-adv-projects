//
//  NetworkDiscovery.m
//  Discover
//
//  Created by Florian Pflug on 13.05.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>

#include <CoreFoundation/CoreFoundation.h>

#import "NetworkDiscovery.h"

#define DISCOVERY_PORT 1234
#define DISCOVERY_INTERVAL 1.0

@implementation NetworkDiscovery

@synthesize peers;

+ (NSArray*)interfaceNamesAddresses {
	/* Compute the sizes of ifreq structures
	   containing an IP and an IPv6 address */
	const size_t ifreq_size_in = IFNAMSIZ + sizeof(struct sockaddr_in);
	const size_t ifreq_size_in6 = IFNAMSIZ + sizeof(struct sockaddr_in6);

	NSArray* result = nil;

	/* Create a dummy socket to execute the IO control on */
	int sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock < 0)
		goto done;

	/* Repeatedly call the IO control with increasing buffer sizes
	   until the IO control leaves enough space unused to convice us
	   that it didn't skip results due to missing buffer space.
	 */
	struct ifconf cfg;
	size_t buffer_capacity = ifreq_size_in6;
	char* buffer = NULL;
	do {
		buffer_capacity *= 2;
		char* buffer_new = (char*)realloc(buffer, buffer_capacity);
		if (buffer_new)
			buffer = buffer_new;
		else
			goto done;
		cfg.ifc_len = buffer_capacity;
		cfg.ifc_buf = buffer;

		if ((ioctl(sock, SIOCGIFCONF, &cfg) < 0) && (errno != EINVAL))
			goto done;
	} while ((buffer_capacity - cfg.ifc_len) < 2*ifreq_size_in6);

	/* Copy the interface names and associated addresses into the result array */
	NSMutableArray* names = [NSMutableArray arrayWithCapacity:(buffer_capacity / ifreq_size_in)];
	while(cfg.ifc_len >= ifreq_size_in) {
		/* Skip entries for non-internet addresses */
		if (cfg.ifc_req->ifr_addr.sa_family == AF_INET) {
			NSString* name = [NSString stringWithCString:cfg.ifc_req->ifr_name];
			const struct sockaddr_in* addr_in = (const struct sockaddr_in*) &cfg.ifc_req->ifr_addr;
			in_addr_t addr = addr_in->sin_addr.s_addr;
			/* Skip entries without an interface name or address */
			if ((name.length > 0) && (addr != INADDR_NONE))
				[names addObject:[NSDictionary dictionaryWithObjectsAndKeys:
								  name, @"name",
								  [NSNumber numberWithUnsignedInt:ntohl(addr)], @"address",
								  nil]];
		}

		/* Move to the next structure in the buffer */
		cfg.ifc_len -= IFNAMSIZ + cfg.ifc_req->ifr_addr.sa_len;
		cfg.ifc_buf += IFNAMSIZ + cfg.ifc_req->ifr_addr.sa_len;
	}
	result = names;
	
done:
	/* Free the buffer and close the socket if necessary */
	if (buffer)
		free(buffer);
	if (sock >= 0)
		close(sock);

	return result;
}


+ (short) interfaceFlags:(NSString*)interface {
	short flags = 0;

	/* Create a dummy socket to execute the IO control on */
	int sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock < 0)
		goto done;

	/* Request structure for SIOCGIFFLAGS */
	struct ifreq req;

	/* Copy the interface name into the structure */
	if (![interface getCString:req.ifr_name
					maxLength:IFNAMSIZ
					 encoding:NSASCIIStringEncoding])
		goto done;
	
	/* Execute the IO control */
	if (ioctl(sock, SIOCGIFFLAGS, &req) != 0)
		goto done;
		
	flags = req.ifr_flags;
	
done:
	close(sock);
	return flags;
}

+ (void)sockaddr_in:(struct sockaddr_in*)sa_in setAddress:(in_addr_t)addr port:(in_port_t)port {
	/* Set address family and structure size */
	sa_in->sin_len = sizeof(struct sockaddr_in);
	sa_in->sin_family = AF_INET;
	/* Set address and port */
	sa_in->sin_addr.s_addr = htonl(addr);
	sa_in->sin_port = htons(port);
}


static NetworkDiscovery* NetworkDiscovery_instance = nil;


+ (void)setup {
	if (!NetworkDiscovery_instance)
		NetworkDiscovery_instance = [[NetworkDiscovery alloc] init];
}


+ (NetworkDiscovery*) instance {
	return NetworkDiscovery_instance;
}


+ (void)shutdown {
	if (NetworkDiscovery_instance) {
		[NetworkDiscovery_instance stop];
		[NetworkDiscovery_instance release];
		NetworkDiscovery_instance = nil;
	}
}


static void NetworkDiscovery_CFSocketCallBack(
	CFSocketRef s,
	CFSocketCallBackType callbackType,
	CFDataRef address,
	const void *data,
	void *info
) {
	const struct sockaddr_in* src = (const struct sockaddr_in*)CFDataGetBytePtr(address);

	if (callbackType == kCFSocketDataCallBack)
		[(NetworkDiscovery*)info onDatagram:(NSData*)data
								fromAddress:ntohl(src->sin_addr.s_addr)
									   port:ntohs(src->sin_port)];
}


- (id)init {
	/* Initialize instance variables */
	peers = [[NSMutableDictionary alloc] init];
	socket_bsd = -1;
	socket_cf = nil;
	socket_runloopsource = nil;
	timer = nil;
	previousHelloResult = NO;


	/* Create the BSD socket */
	socket_bsd = socket(AF_INET, SOCK_DGRAM, 0);
	if (socket_bsd < 0 )
		goto fail;
		

	/* Listen on all available interfaces on the DISCOVERY_PORT */
	struct sockaddr_in srcaddr_in;
	[NetworkDiscovery sockaddr_in:&srcaddr_in
					   setAddress:INADDR_ANY
							 port:DISCOVERY_PORT];
	if (bind(socket_bsd, (const struct sockaddr*)&srcaddr_in, sizeof(srcaddr_in)) != 0)
		goto fail;
	
	
	/* Create a CFSocket wrapping the raw bsd socket */
	CFSocketContext ctx;
	ctx.version = 0;
	ctx.info = self;
	ctx.retain = NULL;
	ctx.release = NULL;
	ctx.copyDescription = NULL;
	socket_cf = CFSocketCreateWithNative(
		kCFAllocatorDefault,
		socket_bsd,
		kCFSocketDataCallBack,
		NetworkDiscovery_CFSocketCallBack,
		&ctx
	);
	if (!socket_cf)
		goto fail;
	
	/* Call the data callback everytime new data arrives but
	   dont't close the raw bsd socket upon destruction of the
	   CFSocket.
	 */
	CFSocketSetSocketFlags(socket_cf, kCFSocketAutomaticallyReenableDataCallBack);

	/* Create a runloop source for the CFSocket */
	socket_runloopsource = CFSocketCreateRunLoopSource(
		kCFAllocatorDefault,
		socket_cf,
		0
	);
	if (!socket_runloopsource)
		goto fail;

	/* And add it to the runloop. */
	CFRunLoopAddSource(CFRunLoopGetCurrent(), socket_runloopsource, kCFRunLoopCommonModes);


	/* Create a timer to periodically send hello datagrams
	   and to remove stale peer entries. */	
	timer = [[NSTimer scheduledTimerWithTimeInterval:DISCOVERY_INTERVAL
												   target:self
												 selector:@selector(onTimer:)
												 userInfo:nil
												  repeats:YES]
				  retain];
	if (!timer)
	  goto fail;

	/* Call Timer immediatly at startup too */
	[self onTimer:timer];

	/* To be sure everyone is up to date send a peers changed notification */
	[[NSNotificationCenter defaultCenter] postNotificationName:@"PeersChanged" object:self];	


	/* Successfully initialized */
	return self;

fail:
	[self stop];
	[self release];
	return nil;
}


- (BOOL)sendData:(NSData*)data toAddress:(in_addr_t)dstAddr port:(in_port_t)dstPort {
	/* Write the destination address and port to a truct sockaddr_in */
	struct sockaddr_in dstaddr_in;
	[NetworkDiscovery sockaddr_in:&dstaddr_in setAddress:dstAddr port:dstPort];

	/* Send packet */
	return (sendto(socket_bsd, data.bytes, data.length, 0, (const struct sockaddr*)&dstaddr_in, sizeof(dstaddr_in)) == data.length);  
}


- (BOOL)multicastData:(NSData*)data toGroup:(in_addr_t)mcGroup port:(in_port_t)dstPort onInterfaceWithAddress:(in_addr_t)ifaceAddr {
	/* Get multicast source interface */
	struct in_addr sin_addr_original;
	socklen_t sin_addr_original_size = sizeof(sin_addr_original);
	if (getsockopt(socket_bsd, IPPROTO_IP, IP_MULTICAST_IF, &sin_addr_original, &sin_addr_original_size) != 0)
		return false;

	/* Set source interface used for multicasting */
	struct in_addr sin_addr;
	sin_addr.s_addr = htonl(ifaceAddr);
	if (setsockopt(socket_bsd, IPPROTO_IP, IP_MULTICAST_IF, &sin_addr, sizeof(sin_addr)) != 0)
		return false;
	
	BOOL result = [self sendData:data toAddress:mcGroup port:dstPort];
	
	/* Reset multicast source interface */
	if (setsockopt(socket_bsd, IPPROTO_IP, IP_MULTICAST_IF, &sin_addr_original, sin_addr_original_size) != 0)
		NSLog(@"Warning: Unable to reset multicast source interface after sending multicast packet.");
		
	return result;
}


- (BOOL)multicastData:(NSData*)data toGroup:(in_addr_t)mcGroup port:(in_port_t)dstPort {
	BOOL result = NO;

	/* We consinder active non-point-to-point, non-loopback interfaces with multicasting
	   capability
	 */
	short flags_on = IFF_MULTICAST | IFF_UP;
	short flags_off = IFF_POINTOPOINT | IFF_LOOPBACK;

	/* Send the data to the specified group and port on every multicast-capable interfaces
	   with an IP address other than 127.0.0.1 (INADDR_LOOPBACK) */
	for(NSDictionary* iface in [NetworkDiscovery interfaceNamesAddresses]) {
		NSString* iface_name = [iface objectForKey:@"name"];
		short iface_flags = [NetworkDiscovery interfaceFlags:iface_name];
		if (((iface_flags & flags_on) == flags_on) && !(iface_flags & flags_off)) {
			NSNumber* iface_addr = (NSNumber*)[iface objectForKey:@"address"];
			BOOL iface_result = [self multicastData:data
											toGroup:mcGroup
											   port:dstPort
							 onInterfaceWithAddress:iface_addr.unsignedIntValue];
			result = result || iface_result;
		}
	}

	return result;
}


- (void)onTimer:(NSTimer*)timer {
	/* Multicast our device name to the all-hosts group on all interfaces */
	BOOL result = [self multicastData:[[[UIDevice currentDevice] name]
									   dataUsingEncoding:NSUTF8StringEncoding]
							  toGroup:INADDR_ALLHOSTS_GROUP
								 port:DISCOVERY_PORT];
	
	/* Notify other parts of the application if WiFi availability changed.
	   We assume WiFi is available if we were able to multicast on at least one interface
	 */
	if (result && !previousHelloResult)	
	  [[NSNotificationCenter defaultCenter] postNotificationName:@"WiFiAvailable" object:self];
	else if (!result && previousHelloResult)
	  [[NSNotificationCenter defaultCenter] postNotificationName:@"WiFiNotAvailable" object:self];
	previousHelloResult = result;
	
	/* Remove stale entries from the peers dictionary. */
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	NSMutableDictionary* peers_new = [[NSMutableDictionary alloc] init];
	for(NSString* peer in peers) {
		CFAbsoluteTime time = [((NSNumber*)[peers objectForKey:peer]) doubleValue];
		if (time > now - 3.0*DISCOVERY_INTERVAL)
			[peers_new setObject:[peers objectForKey:peer]
						  forKey:peer];
	}
	BOOL peer_removed = (peers.count != peers_new.count);	
	[peers release];
	peers = peers_new;

	/* Notify if a peer was removed */
	if (peer_removed)
		[[NSNotificationCenter defaultCenter] postNotificationName:@"PeersChanged" object:self];	
}


- (void)onDatagram:(NSData*)data fromAddress:(in_addr_t)srcAddr port:(in_port_t)srcPort {
	/* Interpret the datagram as the peer's name encoded in UTF-8.
	   Store the current time in the peers dictionary using the peer's name as key */
	NSString* peer = [[[NSString alloc] initWithData:data
											encoding:NSUTF8StringEncoding]
					  autorelease];
	NSNumber* time = [NSNumber numberWithDouble:CFAbsoluteTimeGetCurrent()];

	/* Store peer and current time, remembering whether the peer was already known or not */
    BOOL peer_added = ([peers objectForKey:peer] == nil);
	[peers setObject:time forKey:peer];
	
	/* Notify if a new peer was added */
	if (peer_added)
		[[NSNotificationCenter defaultCenter] postNotificationName:@"PeersChanged" object:self];
}


- (void)stop {
	if (timer) {
		[timer invalidate];
		[timer release];
		timer = nil;
	}

	if (socket_runloopsource) {
		CFRunLoopSourceInvalidate(socket_runloopsource);
		CFRelease(socket_runloopsource);
		socket_runloopsource = nil;
	}
	
	if (socket_cf) {
		CFSocketInvalidate(socket_cf);
		CFRelease(socket_cf);
		socket_cf = nil;
	}
	
	if (socket_bsd >= 0) {
		close(socket_bsd);
		socket_bsd = -1;
	}
}


- (void)dealloc {
	[self stop];

	if (peers) {
		[peers release];
		peers = nil;
	}

	[super dealloc];
}


@end
