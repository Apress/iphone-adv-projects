//
//  NetworkDiscoveryPeerTable.m
//  Discover
//
//  Created by Florian Pflug on 13.05.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "NetworkDiscoveryPeerTable.h"

#import "NetworkDiscovery.h"

@implementation NetworkDiscoveryPeerTable

- (id) init {
	if ((self = [super init])) {
		[self setup];
	}
	
	return self;
}

- (id)initWithCoder:(NSCoder *)decoder {
	if ((self = [super initWithCoder:decoder]))
		[self setup];
	return self;
}

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]))
		[self setup];
	return self;
}

- (void) setup {
	peers = [[NSArray alloc] init];
	wiFiAvailable = NO;
}

- (void)viewDidLoad {
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(onPeersChanged:)
												 name:@"PeersChanged"
											   object:nil];

	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(onWiFiAvailable)
												 name:@"WiFiAvailable"
											   object:nil];

	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(onWiFiNotAvailable)
												 name:@"WiFiNotAvailable"
											   object:nil];

    [super viewDidLoad];
}

-(void)onPeersChanged:(id)sender {
	[peers release];

	if ([NetworkDiscovery instance])
		peers = [[[NetworkDiscovery instance].peers.allKeys
				  sortedArrayUsingSelector:@selector(compare:)]
				 retain];
	else
		peers = [[NSArray alloc] init];
		
	[self.tableView reloadData];
}

-(void)onWiFiAvailable {
	wiFiAvailable = YES;
	[self.tableView reloadData];
}

-(void)onWiFiNotAvailable {
	wiFiAvailable = NO;
	[self.tableView reloadData];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (wiFiAvailable)
		return peers.count;
	else
		return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
    }
    
	if (wiFiAvailable)
		cell.text = [peers objectAtIndex:indexPath.row];
	else
		cell.text = @"No WiFi available";

    return cell;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	[peers release];
    [super dealloc];
}


@end

