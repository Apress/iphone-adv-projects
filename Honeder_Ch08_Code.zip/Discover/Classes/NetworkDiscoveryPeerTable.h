//
//  NetworkDiscoveryPeerTable.h
//  Discover
//
//  Created by Florian Pflug on 13.05.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NetworkDiscoveryPeerTable : UITableViewController {
	NSArray* peers;
	BOOL wiFiAvailable;
}

-(void)setup;

-(void)onPeersChanged:(id)sender;
-(void)onWiFiAvailable;
-(void)onWiFiNotAvailable;

@end
