//
//  DiscoverAppDelegate.m
//  Discover
//
//  Created by Florian Pflug on 13.05.09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "DiscoverAppDelegate.h"
#import "DiscoverViewController.h"
#import "NetworkDiscovery.h"

@implementation DiscoverAppDelegate

@synthesize window;
@synthesize viewController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}

- (void)applicationWillResignActive:(UIApplication *)application {
	/* Cease network transmissions while locked */
	[NetworkDiscovery shutdown];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	/* Restart network transmissions when unlocked */
	[NetworkDiscovery setup];
}

- (void)dealloc {
	[NetworkDiscovery shutdown];

    [viewController release];
    [window release];

    [super dealloc];
}


@end
