//
//  BBSceneZero.m
//  particles
//
//  Created by ben smith on 6/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneZero.h"


@implementation BBSceneZero
-(void)awake
{
	[super awake];
	[[BBMaterialController sharedMaterialController] loadAtlasData:@"particleAtlas"];

	// explosion
	particles = [[BBParticleSystem alloc] init];
	particles.position = BBPointMake(0.0, 0.0, -50.0);
	particles.emissionRange = BBRangeMake(2500,2500);
	particles.xVelocityRange = BBRangeMake(-500, 1000);
	particles.yVelocityRange = BBRangeMake(-500, 1000);
	particles.zVelocityRange = BBRangeMake(-500, 1000);
	particles.decayRange = BBRangeMake(2, 0.00);
	particles.emitCounter = 0.10;
	
	particles.force = BBPointMake(0.0, 0.0, 0.0);
	particles.growRange = BBRangeMake(-1.0, 0.5);
	
	particles.sizeRange = BBRangeMake(2, 2);
	particles.lifeRange = BBRangeMake(10.0, 0.0);
	
	
	particles.emitVolumeYRange = BBRangeMake(-10, 20);
	
	particles.emit = NO;
	[particles setParticle:@"whiteSubtle"];
	[self addChild:particles];
}	

-(void)update:(NSTimeInterval)deltaTime
{
	[super update:deltaTime];
	// check our emit status
	if (particles.emit == NO) {
		particles.emitCounter = .10;
	}
}

-(void)emitButtonDown
{
	particles.emit = YES;
}


@end
