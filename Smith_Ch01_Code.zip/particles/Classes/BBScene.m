//
//  BBScene.m
//  particles
//
//  Created by ben smith on 6/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBScene.h"
#import "BBGeneralInterface.h"
#import "BBParticleSystem.h"
#import "BBButton.h"
#import "BBDisplay.h"


@implementation BBScene
-(void)awake
{
	[[BBMaterialController sharedMaterialController] loadAtlasData:@"particleAtlas"];

	// the UI object holds all the buttons to switch between each scene
	uiObject = [[BBGeneralInterface alloc] init];
	[uiObject awake];

	
	// this button covers most of the screen, it is effectively a touch 
	// event trigger for the main screen area
	BBButton* emitButton = [[BBButton alloc] init];
	emitButton.scale = BBPointMake(400, 320, 1.0);	
	emitButton.position = BBPointMake(-40.0, 0.0, 0.0);	
	emitButton.target = self;
	emitButton.buttonDownAction = @selector(emitButtonDown);
	emitButton.buttonUpAction = @selector(emitButtonUp);
	emitButton.render = NO;
	[emitButton awake];
	[[BBSceneController sharedSceneController].inputController addInterfaceObject:emitButton];
	[emitButton release];	
	
	// the HUD shows FPS and total number of particles 
	BBDisplay * hud = [[BBDisplay alloc] init];
	[self addChild:hud];
	[hud release];
}	

-(void)emitButtonDown
{
}

-(void)emitButtonUp
{
}


- (void) dealloc
{
	[uiObject release];
	[particles release];
	[super dealloc];
}

@end
