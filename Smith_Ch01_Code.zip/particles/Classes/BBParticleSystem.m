//
//  BBParticleSystem.m
//  SkateDude
//
//  Created by ben smith on 28/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBParticleSystem.h"
#import "BBParticle.h"



@implementation BBParticleSystem

@synthesize emit,force,sphericalEmissionVolume,animateColor;
@synthesize emissionRange, sizeRange, growRange, xVelocityRange, yVelocityRange,zVelocityRange;
@synthesize lifeRange,decayRange,emitCounter;
@synthesize emitVolumeXRange,emitVolumeYRange,emitVolumeZRange;
@synthesize startR,startG,startB,startA;
@synthesize endR,endG,endB,endA;

- (id) init
{
	self = [super init];
	if (self != nil) {
		[self preload];
		[self setDefaultSystem];
		negOneToOne = BBRangeMake(-1.0, 2.0);// the range -1 .. 1
		zeroToOne = BBRangeMake(0.0, 1.0); // the range 0 .. 1
		particleRemainder = 0.0;
		sphericalEmissionVolume = YES;
		animateColor = NO;
	}
	return self;
}

-(void)setDefaultSystem
{
	self.emissionRange = BBRangeMake(1.0, 2.0);
	self.emitVolumeXRange = BBRangeMake(0.0, 0.0);
	self.emitVolumeYRange = BBRangeMake(0.0, 0.0);
	self.emitVolumeZRange = BBRangeMake(0.0, 0.0);
	self.sizeRange = BBRangeMake(4.0, 8.0);
	self.growRange = BBRangeMake(-0.5, -0.1);
	self.xVelocityRange = BBRangeMake(0.0, 0.0);
	self.yVelocityRange = BBRangeMake(0.0, 0.0);
	self.lifeRange = BBRangeMake(1.0, 0.0);
	self.decayRange = BBRangeMake(0.1, 0.0);
	self.force = BBPointMake(0.0, 0.0, 0.0);
	self.emit = NO;
	emitCounter = 10000;
}

-(void)preload
{
	if (childrenParticles == nil) childrenParticles = [[NSMutableArray alloc] init];
	unusedParticles = [[NSMutableArray alloc] initWithCapacity:kMaxParticles];
	NSInteger count = 0;
	for (count = 0; count < kMaxParticles; count++) {
		BBParticle * p = [[BBParticle alloc] init];
		[unusedParticles addObject:p];
		[p release];
	}
	
	// remember 6 vertexes per particle
	vertexes = (CGFloat *) malloc(2 * 6 * kMaxParticles * sizeof(CGFloat));
	uvCoordinates = (CGFloat *) malloc(2 * 6 * kMaxParticles * sizeof(CGFloat));
	colors = (CGFloat *) malloc(4 * 6 * kMaxParticles * sizeof(CGFloat));
}


-(void)setParticle:(NSString*)atlasKey
{
	BBTexturedQuad * quad = [[BBMaterialController sharedMaterialController] quadFromAtlasKey:atlasKey];
	self.mesh = [[BBTexturedQuad alloc] init];
	[(BBTexturedQuad*)mesh setMaterialKey:quad.materialKey];
	[(BBTexturedQuad*)mesh setAtlasKey:quad.atlasKey];
	
	// need to calculate the min and max UV
	CGFloat u,v;
	NSInteger index;
	minU = minV = 1.0;
	maxU = maxV = 0.0;
	CGFloat * uvs = [quad uvCoordinates];
	for (index = 0; index < quad.vertexCount; index++) {
		u = uvs[index * 2];
		v = uvs[(index * 2) + 1];
		if (u < minU) minU = u;
		if (v < minV) minV = v;
		if (u > maxU) maxU = u;
		if (v > maxV) maxV = v;
	}	

	mesh.vertexes = vertexes;

	[(BBTexturedQuad*)mesh setUvCoordinates:uvCoordinates];
	
	mesh.vertexSize = 2;
	mesh.renderStyle = GL_TRIANGLES;
	
	mesh.colors = colors;
	mesh.colorSize = 4;
}


-(void)buildVertexArrays
{
	vertexIndex = 0;
	for (BBParticle * particle in childrenParticles) {
		// check to see if we have run out of life, or are too small to see
		// and if they are, then queue them for removal
		if ((particle.life < 0) || (particle.size < 0.3)) {
			[self removeChildParticle:particle];
			continue; // skip to the next particle, no need to add this one
		}
				
		if (animateColor) {
			[self addColorsR:particle.r g:particle.g b:particle.b a:particle.a vertexes:6]; 
		}
		// for each particle, need 2 triangles, so 6 verts
		// first triangle of the quad.  Need to load them in clockwise
		// order since our models are in that order
		[self addVertex:(particle.position.x - particle.size) y:(particle.position.y + particle.size) u:minU v:minV];
		[self addVertex:(particle.position.x + particle.size) y:(particle.position.y - particle.size) u:maxU v:maxV];
		[self addVertex:(particle.position.x - particle.size) y:(particle.position.y - particle.size) u:minU v:maxV];
		
		// second triangle of the quad
		[self addVertex:(particle.position.x - particle.size) y:(particle.position.y + particle.size) u:minU v:minV];
		[self addVertex:(particle.position.x + particle.size) y:(particle.position.y + particle.size) u:maxU v:minV];
		[self addVertex:(particle.position.x + particle.size) y:(particle.position.y - particle.size) u:maxU v:maxV];
		
	}
	mesh.vertexCount = vertexIndex;	
	[BBSceneController sharedSceneController].totalVerts += vertexIndex;
}

-(void)update:(NSTimeInterval)deltaTime
{
	// update active particles -> move them
	[super update:deltaTime];
	for (BBParticle * kid in childrenParticles) {
		[kid update:deltaTime];
		if (animateColor) {
			kid.r = BBLerp(startR, endR, (kid.startingLife - kid.life)/kid.startingLife);
			kid.g = BBLerp(startG, endG, (kid.startingLife - kid.life)/kid.startingLife);
			kid.b = BBLerp(startB, endB, (kid.startingLife - kid.life)/kid.startingLife);
			kid.a = BBLerp(startA, endA, (kid.startingLife - kid.life)/kid.startingLife);
		}	
	}
	// emit -> add new particles
	// build arrays
	[self buildVertexArrays];
	[self emitNewParticles:deltaTime];
	if (animateColor) [(BBTexturedQuad*)[self mesh] setUseColors:YES];
}


-(void)emitNewParticles:(NSTimeInterval)deltaTime
{
	if (!emit) return;
	if (emitCounter > 0) emitCounter -= deltaTime; 
	if (emitCounter <= 0) emit = NO;
	
	CGFloat newChance = ([self randomFloat:emissionRange] * deltaTime);
	particleRemainder += newChance;
	
	if (particleRemainder < 1.0) return;
	
	NSInteger newParticleCount = (NSInteger)particleRemainder;
	particleRemainder -= newParticleCount;
	
	NSInteger index;
	for (index = 0; index < newParticleCount; index++) {
		if ([unusedParticles count] == 0) {
			return;
		} 
		BBParticle * p = [unusedParticles lastObject];
		p.position = [self newParticlePosition];
		p.velocity = [self newParticleVelocity];
		
		p.force = force;
		
		p.r = startR;
		p.g = startG;
		p.b = startB;
		p.a = startA;
		
		p.life = BBRandomFloat(lifeRange);
		p.startingLife = p.life; // set so we can do color animation
		p.size = BBRandomFloat(sizeRange);
		p.grow = BBRandomFloat(growRange);
		p.decay = BBRandomFloat(decayRange);
		
		[self addChildParticle:p];
		[unusedParticles removeLastObject];
	}
}

// a random position around my position
-(BBPoint)newParticlePosition
{
	if (!sphericalEmissionVolume) return BBPointMake(BBRandomFloat(emitVolumeXRange),BBRandomFloat(emitVolumeYRange),BBRandomFloat(emitVolumeZRange));
	
	BBPoint rawPos = BBPointMake([self randomFloat:zeroToOne],[self randomFloat:zeroToOne],[self randomFloat:zeroToOne]);
	if ((rawPos.x * rawPos.x + rawPos.y * rawPos.y + rawPos.z * rawPos.z) > 1.0) rawPos =  BBPointNormalize(rawPos);
	rawPos.x *= [self randomFloat:emitVolumeXRange];
	rawPos.y *= [self randomFloat:emitVolumeYRange];
	rawPos.z *= [self randomFloat:emitVolumeZRange];
	return rawPos;
}

-(BBPoint)newParticleVelocity
{
	return BBPointMake( BBRandomFloat(xVelocityRange),BBRandomFloat(yVelocityRange),BBRandomFloat(zVelocityRange));
}


//	BBPoint rawVelo = BBPointMake([self randomFloat:zeroToOne],
//																[self randomFloat:zeroToOne],
//																[self randomFloat:zeroToOne]);
//	if ((rawVelo.x * rawVelo.x + rawVelo.y * rawVelo.y + rawVelo.z * rawVelo.z) > 1.0) rawVelo =  BBPointNormalize(rawVelo);
//	rawVelo.x *= [self randomFloat:xVelocityRange];
//	rawVelo.y *= [self randomFloat:yVelocityRange];
//	rawVelo.z *= [self randomFloat:zVelocityRange];
//	return rawVelo;



-(CGFloat)randomFloat:(BBRange)range
{
	// returna a random float in the range
	CGFloat randPercent = ((CGFloat)RANDOM_INT(0,10000)) / 10000.0;
	CGFloat offset = randPercent * range.length;
	return offset + range.start;
}

-(void)addChildParticle:(BBParticle*)particle
{
	if (objectsToAdd == nil) objectsToAdd = [[NSMutableArray alloc] init];
	[objectsToAdd addObject:particle];
}

-(void)removeChildParticle:(BBParticle*)particle
{
	if (objectsToRemove == nil) objectsToRemove = [[NSMutableArray alloc] init];
	[objectsToRemove addObject:particle];
}

-(BOOL)isOnscreen
{
	return YES;
}

-(void)preLoopProcess
{
	// add any queued scene objects
	if ([objectsToAdd count] > 0) {
		[childrenParticles addObjectsFromArray:objectsToAdd];
		[objectsToAdd removeAllObjects];
	}	
}

-(void)postLoopProcess
{
	// remove any objects that need removal
	if ([objectsToRemove count] > 0) {
		[childrenParticles removeObjectsInArray:objectsToRemove];
		[unusedParticles addObjectsFromArray:objectsToRemove];
		[objectsToRemove removeAllObjects];
	}
}

-(void)addColorsR:(CGFloat)r g:(CGFloat)g b:(CGFloat)b a:(CGFloat)a vertexes:(NSInteger)verts
{
	NSInteger index;
	for (index = vertexIndex; index < (vertexIndex + verts); index++){
		NSInteger pos = index * 4.0;
		colors[pos] = r;
		colors[pos + 1] = g;
		colors[pos + 2] = b;
		colors[pos + 3] = a;
	} 
}


-(void)addVertex:(CGFloat)x y:(CGFloat)y u:(CGFloat)u v:(CGFloat)v
{
	NSInteger pos = vertexIndex * 2.0;
	vertexes[pos] = x;
	vertexes[pos + 1] = y;
	uvCoordinates[pos] = u;
	uvCoordinates[pos + 1] = v;
	vertexIndex++;
}

- (void) dealloc
{
	[unusedParticles release];
	[childrenParticles release];

	free(vertexes);
	free(uvCoordinates);
	
	[super dealloc];
}

@end
