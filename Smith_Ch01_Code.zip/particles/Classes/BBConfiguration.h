// this is the config file
// it holds all the constants and other various and sundry items that
// we need and dont want to hardcode in the code

#define RANDOM_SEED() srandom(time(NULL))
#define RANDOM_INT(__MIN__, __MAX__) ((__MIN__) + random() % ((__MAX__+1) - (__MIN__)))

#define kFPS 30.0

// a handy constant to keep around
#define BBRADIANS_TO_DEGREES 57.2958

// material import settings
#define BB_CONVERT_TO_4444 0

#define kPi			3.14159 

#define kMaxParticles 10000
