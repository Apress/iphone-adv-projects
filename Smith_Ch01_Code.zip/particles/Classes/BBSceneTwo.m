//
//  BBSceneTwo.m
//  particles
//
//  Created by ben smith on 6/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneTwo.h"


@implementation BBSceneTwo
-(void)awake
{
	[super awake];
	[[BBMaterialController sharedMaterialController] loadAtlasData:@"particleAtlas"];
	
	particles = [[BBParticleSystem alloc] init];
	particles.position = BBPointMake(0.0, 0.0, -50.0);
	
	particles.emissionRange = BBRangeMake(50,50);
	particles.xVelocityRange = BBRangeMake(0, 0);
	particles.yVelocityRange = BBRangeMake(0, 0);
	particles.zVelocityRange = BBRangeMake(0, 0);
	
	particles.emitVolumeXRange = BBRangeMake(-100, 200);
	particles.emitVolumeYRange = BBRangeMake(-100, 200);
	
	particles.force = BBPointMake(0.0, 0.0, 0.0);
	particles.growRange = BBRangeMake(-1.0, 0.50);
	
	particles.sizeRange = BBRangeMake(1, 6);
	
	particles.lifeRange = BBRangeMake(10.0, 0.0);
	particles.decayRange = BBRangeMake(0.1, 0.00);
	
	// this will make it a rectangular emission volume
	//particles.sphericalEmissionVolume = NO;
	
	particles.emit = YES;
	[particles setParticle:@"bang2"];
	[self addChild:particles];
}

@end
