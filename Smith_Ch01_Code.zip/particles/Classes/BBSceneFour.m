//
//  BBSceneFour.m
//  particles
//
//  Created by ben smith on 7/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneFour.h"


@implementation BBSceneFour
-(void)awake
{
	[super awake];
	[[BBMaterialController sharedMaterialController] loadAtlasData:@"particleAtlas"];
	
	particles = [[BBParticleSystem alloc] init];
	
	// this is a copy of the flames from Scene Three
	// I left this in as a place to start.
//	particles.position = BBPointMake(0.0, -80.0, -50.0);
//	
//	particles.emissionRange = BBRangeMake(40,50);
//	particles.xVelocityRange = BBRangeMake(0, 0);
//	particles.yVelocityRange = BBRangeMake(1, 10);
//	particles.zVelocityRange = BBRangeMake(0, 0);
//	
//	particles.emitVolumeXRange = BBRangeMake(-30, 60);
//	particles.emitVolumeYRange = BBRangeMake(-15, 10);
//	
//	particles.force = BBPointMake(0.0, 10.0, 0.0);
//	particles.growRange = BBRangeMake(-1.5, 1.5);
//	
//	particles.sizeRange = BBRangeMake(6, 6);
//	
//	particles.lifeRange = BBRangeMake(2.5, 0.0);
//	particles.decayRange = BBRangeMake(0.5, 0.1);
//	
//	// start with a nice pure yellow
//	particles.startR = 1.0;
//	particles.startG = 1.0;
//	particles.startB = 0.0;
//	particles.startA = 1.0;
//	
//	// end with a dark red
//	particles.endR = 0.5;
//	particles.endG = 0.0;
//	particles.endB = 0.0;
//	particles.endA = 1.0;
//	
//	// this will make it a rectangular emission volume
//	//particles.sphericalEmissionVolume = NO;
//	particles.animateColor = YES;
//	
//	particles.emit = YES;
//	[particles setParticle:@"whiteBlur"];
	[self addChild:particles];
}

@end
