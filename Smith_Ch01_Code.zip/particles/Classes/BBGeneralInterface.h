//
//  BBGeneralInterface.h
//  particles
//
//  Created by ben smith on 5/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneObject.h"


@interface BBGeneralInterface : BBSceneObject {

}

@end
