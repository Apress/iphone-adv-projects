//
//  BBInputViewController.h
//  BBOpenGLGameTemplate
//
//  Created by ben smith on 1/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BBGameTypes.h"

@class BBRenderController;
@class BBSceneObject;
@class BBInterfaceObject;

@interface BBInputViewController : UIViewController {
	NSMutableSet* touchEvents;
	
	NSMutableArray * interfaceObjects;
	NSMutableArray * touchesToDistribute;

	
	CGFloat forwardMagnitude;
	CGFloat rightMagnitude;
	CGFloat leftMagnitude;
	BOOL fireMissile;
}

@property (retain) NSMutableSet* touchEvents;
@property (assign) CGFloat forwardMagnitude;
@property (assign) BOOL fireMissile;
@property (assign) CGFloat rightMagnitude;
@property (assign) CGFloat leftMagnitude;

+ (BBPoint)gamePointFromScreenPoint:(CGPoint)p;
- (CGRect)screenRectFromMeshRect:(CGRect)rect atPoint:(CGPoint)meshCenter;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil ;
- (void)addInterfaceObject:(BBInterfaceObject*)interfaceObject;
- (void)clearEvents;
- (void)clearInterface;
- (void)dealloc ;
- (void)didReceiveMemoryWarning ;
- (void)distributeTouches;
- (void)loadView;
- (void)removeInterfaceObject:(BBInterfaceObject*)interfaceObject;
- (void)renderInterface:(BBRenderController*)renderer;
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)updateInterface:(NSTimeInterval)deltaTime;
- (void)viewDidUnload ;

// 17 methods



@end
