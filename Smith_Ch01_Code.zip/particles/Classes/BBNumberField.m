//
//  BBNumberField.m
//  SkateDude
//
//  Created by ben smith on 27/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBNumberField.h"


@implementation BBNumberField

@synthesize alignment,string;

- (id) init
{
	self = [super init];
	if (self != nil) {
		alignment = UITextAlignmentLeft;
	
	}
	return self;
}

-(void)awake
{
	// pre build a few numbers so I dont have to do it during gametime
	NSInteger index = 0;
	for (index = 0; index < 10; index++) {
		BBSceneObject * chr = [[BBSceneObject alloc] init];
		[self addChild:chr];
		[chr release];		
	}
}

-(void)update:(NSTimeInterval)deltaTime
{
	[super update:deltaTime];
	// first turn off all my children
	for (BBSceneObject * kid in children) kid.render = NO;
	// set my numbers
	[self setNumbers];
}

-(void)setNumbers
{
	// should be all numbers
	NSInteger index = 0;
	CGFloat width = 0;
	while (index < [string length]) {
		NSString * name = [[NSString stringWithFormat:@"%c",[string characterAtIndex:index]] uppercaseString];		
		BBSceneObject * chr = [children objectAtIndex:index];
		chr.mesh = [[BBMaterialController sharedMaterialController] quadFromAtlasKey:name];
		chr.position = BBPointMake(width, 0.0, 0.0);
		chr.render = YES;
		width += CGRectGetWidth(chr.meshBounds) + 4.0;			
		if ([name isEqualToString:@"1"]) width += 3.0;	
		index++;
	}
	if (alignment != UITextAlignmentLeft) {
		for (BBSceneObject* kid in children) {
			BBPoint p = kid.position;
			if (alignment == UITextAlignmentRight) {
				p.x -= width;				
			} else {
				if (alignment == UITextAlignmentCenter) {
					p.x -= width/2.0;
				}				
			}
			kid.position = p;
		}
	}
}
@end
