//
//  BBRenderController.m
//  SkateDude
//
//  Created by ben smith on 21/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBRenderController.h"
#import "BBSceneObject.h"


@implementation BBRenderController

- (id) init
{
	self = [super init];
	if (self != nil) {
		renderArray = [[NSMutableArray alloc] init];
		sortDescriptorArray = [NSArray arrayWithObject:[[NSSortDescriptor alloc] initWithKey:@"depth" ascending:YES]];
		[sortDescriptorArray retain];
	}
	return self;
}


-(void)renderObjects:(NSArray*)sceneObjects
{
	[renderArray removeAllObjects];	
	for (BBSceneObject * child in sceneObjects) {
		[self cullObjects:child];		
	}

//	[self depthSort];
	
	for (BBSceneObject * obj in renderArray) {
		// clear the matrix
		glPushMatrix();
		glMultMatrixf(obj.matrix);
		[obj.mesh render];	
		glPopMatrix();
	}
}

-(void)cullObjects:(BBSceneObject*)rootObject
{
	if (rootObject.render && rootObject.onscreen) [renderArray addObject:rootObject]; 
	
	for (BBSceneObject * obj in rootObject.children) {
		[self cullObjects:obj];
	}
}

-(void)depthSort
{
	[renderArray sortUsingDescriptors:sortDescriptorArray];
}

-(void)renderRootObject:(BBSceneObject*)rootObject
{
	[self renderObjects:[NSArray arrayWithObject:rootObject]];
}

@end
