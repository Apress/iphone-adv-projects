//
//  BBParticleSystem.h
//  SkateDude
//
//  Created by ben smith on 28/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneObject.h"
#import "BBGameTypes.h"

@class BBParticle;

@interface BBParticleSystem : BBSceneObject {
	NSMutableArray * childrenParticles;
	
	GLfloat * uvCoordinates;
	GLfloat * vertexes;
	GLfloat * colors;
	
	NSMutableArray * unusedParticles;
	
	NSInteger vertexIndex;
	
	BOOL emit;
	CGFloat emitCounter;
	
	BBRange emissionRange;
	BBRange sizeRange;
	BBRange growRange;

	BBRange xVelocityRange;
	BBRange yVelocityRange;
	BBRange zVelocityRange;
	
	BBRange lifeRange;
	BBRange decayRange;
	
	BBPoint force;
	
	BBRange emitVolumeXRange;
	BBRange emitVolumeYRange;
	BBRange emitVolumeZRange;
	
	BBRange negOneToOne;
	BBRange zeroToOne;
	
	CGFloat particleRemainder;
	
	CGFloat minU;
	CGFloat maxU;
	CGFloat minV;
	CGFloat maxV;
	
	BOOL sphericalEmissionVolume;	
	
	CGFloat startR;
	CGFloat startG;
	CGFloat startB;
	CGFloat startA;
	
	CGFloat endR;
	CGFloat endG;
	CGFloat endB;
	CGFloat endA;
	
	BOOL animateColor;
	
}

@property (assign) BBPoint force;
@property (assign) BOOL emit;
@property (assign) BOOL sphericalEmissionVolume;
@property (assign) CGFloat emitCounter;

@property (assign) BBRange emissionRange;
@property (assign) BBRange sizeRange;
@property (assign) BBRange growRange;

@property (assign) BBRange xVelocityRange;
@property (assign) BBRange yVelocityRange;
@property (assign) BBRange zVelocityRange;

@property (assign) BBRange emitVolumeXRange;
@property (assign) BBRange emitVolumeYRange;
@property (assign) BBRange emitVolumeZRange;

@property (assign) BBRange lifeRange;
@property (assign) BBRange decayRange;

@property (assign) CGFloat startR;
@property (assign) CGFloat startG;
@property (assign) CGFloat startB;
@property (assign) CGFloat startA;
@property (assign) CGFloat endR;
@property (assign) CGFloat endG;
@property (assign) CGFloat endB;
@property (assign) CGFloat endA;

@property (assign) BOOL animateColor;


- (BBPoint)newParticlePosition;
- (BBPoint)newParticleVelocity;
- (BOOL)isOnscreen;
- (CGFloat)randomFloat:(BBRange)range;
- (id) init;
- (void) dealloc;
- (void)addChildParticle:(BBParticle*)particle;
- (void)addColorsR:(CGFloat)r g:(CGFloat)g b:(CGFloat)b a:(CGFloat)a vertexes:(NSInteger)verts;
- (void)addVertex:(CGFloat)x y:(CGFloat)y u:(CGFloat)u v:(CGFloat)v;
- (void)buildVertexArrays;
- (void)emitNewParticles:(NSTimeInterval)deltaTime;
- (void)postLoopProcess;
- (void)preLoopProcess;
- (void)preload;
- (void)removeChildParticle:(BBParticle*)particle;
- (void)setDefaultSystem;
- (void)setParticle:(NSString*)atlasKey;
- (void)update:(NSTimeInterval)deltaTime;

// 18 methods

@end
