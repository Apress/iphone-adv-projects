//
//  BBSceneObject.m
//  BBOpenGLGameTemplate
//
//  Created by ben smith on 1/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneObject.h"
#import "BBSceneController.h"
#import "BBInputViewController.h"

@implementation BBSceneObject

@synthesize position,rotation,onscreen,scale,render,mesh,matrix,meshBounds,children;
@synthesize depth,parent;

- (id) init
{
	self = [super init];
	if (self != nil) {
		position = BBPointMake(0.0, 0.0, 0.0);
		rotation = BBPointMake(0.0, 0.0, 0.0);
		scale = BBPointMake(1.0, 1.0, 1.0);
		render = YES;
		meshBounds = CGRectZero;
		
		children = [[NSMutableArray alloc] init];
		
	}
	return self;
}


// called once when the object is first created.
-(void)awake
{
	// abstract
}

-(CGRect) meshBounds
{
	if (CGRectEqualToRect(meshBounds, CGRectZero)) {
		meshBounds = [BBMesh meshBounds:mesh scale:scale];
	}
	return meshBounds;
}


-(BOOL)isOnscreen
{
	if (fabs(position.x) > (240.0 + CGRectGetWidth(self.meshBounds)/2.0)) return NO; 
	if (fabs(position.y) > (160.0 + CGRectGetHeight(self.meshBounds)/2.0)) return NO;
	return YES;
}


// called once every frame
-(void)update:(NSTimeInterval)deltaTime
{
	if (matrix == NULL) matrix = (CGFloat *) malloc(16 * sizeof(CGFloat));
	onscreen = [self isOnscreen];
	if (render) {
		glPushMatrix();
		glLoadIdentity();
		if (parent != nil) glMultMatrixf(parent.matrix);
		// move to my position
		glTranslatef(position.x, position.y, position.z);
		// rotate
		glRotatef(rotation.x, 1.0f, 0.0f, 0.0f);
		glRotatef(rotation.y, 0.0f, 1.0f, 0.0f);
		glRotatef(rotation.z, 0.0f, 0.0f, 1.0f);
		
		//scale
		glScalef(scale.x, scale.y, scale.z);
		// save the matrix transform
		glGetFloatv(GL_MODELVIEW_MATRIX, matrix);
		//restore the matrix
		glPopMatrix();
	}
	for (BBSceneObject * kid in children) [kid update:deltaTime];
}



-(void)preLoopProcess
{
	// add any queued scene objects
	if ([objectsToAdd count] > 0) {
		[children addObjectsFromArray:objectsToAdd];
		[objectsToAdd removeAllObjects];
	}	
	[children makeObjectsPerformSelector:@selector(preLoopProcess)];
}

-(void)postLoopProcess
{
	// remove any objects that need removal
	if ([objectsToRemove count] > 0) {
		[children removeObjectsInArray:objectsToRemove];
		[objectsToRemove removeAllObjects];
	}
	[children makeObjectsPerformSelector:@selector(postLoopProcess)];
}

// we dont actualy add the object directly to the scene.
// this can get called anytime during the game loop, so we want to
// queue up any objects that need adding and add them at the start of
// the next game loop
-(void)addChild:(BBSceneObject*)sceneObject
{
	if (objectsToAdd == nil) objectsToAdd = [[NSMutableArray alloc] init];
	sceneObject.render = YES;
	sceneObject.parent = self;
	[sceneObject awake];
	[objectsToAdd addObject:sceneObject];
}

// similar to adding objects, we cannot just remove objects from
// the scene at any time.  we want to queue them for removal 
// and purge them at the end of the game loop
-(void)removeChild:(id)sceneObject
{
	if (objectsToRemove == nil) objectsToRemove = [[NSMutableArray alloc] init];
	[objectsToRemove addObject:sceneObject];
}

-(void)removeAllChildren
{
	if (objectsToRemove == nil) objectsToRemove = [[NSMutableArray alloc] init];
	[objectsToRemove addObjectsFromArray:children];	
}

-(void)destroy
{
	// kill me and all my kids
	for (BBSceneObject * kid in children) {
		[kid destroy];
	}
	[parent removeChild:self];
	self.parent = nil;
}

- (void) dealloc
{
	[children release];
	[objectsToAdd release];
	[objectsToRemove release];
	[mesh release];
	[parent release];
	if (matrix != NULL) free(matrix);		
	[super dealloc];
}

@end
