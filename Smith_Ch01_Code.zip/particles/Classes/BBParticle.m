//
//  BBParticle.m
//  SkateDude
//
//  Created by ben smith on 28/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBParticle.h"


@implementation BBParticle

@synthesize position,velocity,life,size;
@synthesize grow,decay,force;
@synthesize r,g,b,a,startingLife;

-(void)update:(NSTimeInterval)deltaTime
{
	velocity.x += force.x * deltaTime;
	velocity.y += force.y * deltaTime;
	velocity.z += force.z * deltaTime;
	
	position.x += velocity.x * deltaTime;
	position.y += velocity.y * deltaTime;
	position.z += velocity.z * deltaTime;
	
	if (position.y < -280.0) position.y = -280.0;
	
	life -= decay  * deltaTime;
	size += grow  * deltaTime;
	if (size < 0.0) size = 0.0;
}
@end
