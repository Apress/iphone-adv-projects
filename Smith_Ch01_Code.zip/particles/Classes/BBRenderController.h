//
//  BBRenderController.h
//  SkateDude
//
//  Created by ben smith on 21/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

// handles all the rendering

@class BBSceneObject;

@interface BBRenderController : NSObject {
	NSMutableArray * renderArray;
	NSArray * sortDescriptorArray;
}

- (id) init;
- (void)cullObjects:(BBSceneObject*)rootObject;
- (void)depthSort;
- (void)renderObjects:(NSArray*)sceneObjects;
- (void)renderRootObject:(BBSceneObject*)rootObject;

// 5 methods


@end
