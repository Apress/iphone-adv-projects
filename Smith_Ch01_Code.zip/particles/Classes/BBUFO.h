//
//  BBUFO.h
//  SpaceRocks3D
//
//  Created by ben smith on 31/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneObject.h"


@interface BBUFO : BBSceneObject {
}


@end
