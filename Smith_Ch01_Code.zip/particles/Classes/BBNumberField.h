//
//  BBNumberField.h
//  SkateDude
//
//  Created by ben smith on 27/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBInterfaceObject.h"


@interface BBNumberField : BBInterfaceObject {
	NSInteger alignment;

	NSString * string;
}

@property (assign) NSInteger alignment;
@property (retain) NSString * string;

- (id) init;
- (void)awake;
- (void)setNumbers;
- (void)update:(NSTimeInterval)deltaTime;

// 4 methods


@end
