//
//  BBSceneController.m
//  BBOpenGLGameTemplate
//
//  Created by ben smith on 1/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneController.h"
#import "BBInputViewController.h"
#import "EAGLView.h"
#import "BBConfiguration.h"
#import "BBRenderController.h"

#import "BBScene.h"
#import "BBSceneZero.h"
#import "BBSceneOne.h"
#import "BBSceneTwo.h"
#import "BBSceneThree.h"
#import "BBSceneFour.h"

@implementation BBSceneController

@synthesize inputController, openGLView,sceneIndex,currentScene,totalVerts;
@synthesize animationInterval, animationTimer,levelStartTime,deltaTime;

// Singleton accessor.  this is how you should ALWAYS get a reference
// to the scene controller.  Never init your own. 
+(BBSceneController*)sharedSceneController
{
  static BBSceneController *sharedSceneController;
  @synchronized(self)
  {
    if (!sharedSceneController)
      sharedSceneController = [[BBSceneController alloc] init];
		
    return sharedSceneController;
  }
	return sharedSceneController;
}

- (id) init
{
	self = [super init];
	if (self != nil) {
		scenes = [[NSMutableArray alloc] init];
		[scenes addObject:@"BBSceneZero"];
		[scenes addObject:@"BBSceneOne"];
		[scenes addObject:@"BBSceneTwo"];
		[scenes addObject:@"BBSceneThree"];
		[scenes addObject:@"BBSceneFour"];
		sceneIndex = 0;
		renderer = [[BBRenderController alloc] init];
		
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadSceneNotification:) name:@"BBLoadScene" object:nil];
	}
	return self;
}


#pragma mark scene preload

-(void)restartScene
{
	[self loadScene:sceneIndex];
}


-(void)loadSceneNotification:(NSNotification*)note
{
	sceneIndex = [[note object] integerValue];
	if (sceneIndex >= [scenes count]) return;
	needToLoadScene = YES;
}

-(void)unloadCurrentScene
{
	[currentScene destroy];
	self.currentScene = nil;
}

// this is where we initialize all our scene objects
-(void)loadScene:(NSInteger)sceneNumber;
{
	needToLoadScene = NO;
	RANDOM_SEED();
	[self stopAnimation]; // do not want a game loop kicking off during this

	[inputController clearInterface];
	if (sceneNumber >= 0) sceneIndex = sceneNumber;
 
	[self unloadCurrentScene];
	BBSceneObject * newScene = [[NSClassFromString([scenes objectAtIndex:sceneIndex]) alloc] init];
	[newScene awake];
	self.currentScene = newScene;
	[newScene release];
	
	[self startScene];
}


// makes everything go
-(void) startScene
{
	self.animationInterval = 1.0/kFPS;
	[self startAnimation];
	self.levelStartTime = [NSDate date];
	lastFrameStartTime = 0;
}

#pragma mark Game Loop

- (void)gameLoop
{
	// we use our own autorelease pool so that we can control when garbage gets collected
	NSAutoreleasePool * apool = [[NSAutoreleasePool alloc] init];

	
	timeSinceLevelStart = [levelStartTime timeIntervalSinceNow];
	deltaTime =  lastFrameStartTime - timeSinceLevelStart;
	lastFrameStartTime = timeSinceLevelStart;	
	
	[inputController updateInterface:deltaTime];
	// update our model
	[currentScene preLoopProcess];
	[currentScene update:deltaTime];
	// deal with collisions
	[inputController clearEvents];
	
	// send our objects to the renderer
	[self renderScene];
	[currentScene postLoopProcess];

	[apool release];
	if (needToLoadScene) [self loadScene:sceneIndex];
}


- (void)renderScene
{
	// turn openGL 'on' for this frame
	[openGLView beginDraw];
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);

	// simply call 'render' on all our scene objects
	[renderer renderRootObject:currentScene];
	// draw the interface on top of everything
	[inputController renderInterface:renderer];
	// finalize this frame
	[openGLView finishDraw];
}


#pragma mark Animation Timer

// these methods are copied over from the EAGLView template

- (void)startAnimation {
	self.animationTimer = [NSTimer scheduledTimerWithTimeInterval:animationInterval target:self selector:@selector(gameLoop) userInfo:nil repeats:YES];
}

- (void)stopAnimation {
	self.animationTimer = nil;
}

- (void)setAnimationTimer:(NSTimer *)newTimer {
	[animationTimer invalidate];
	animationTimer = newTimer;
}

- (void)setAnimationInterval:(NSTimeInterval)interval {	
	animationInterval = interval;
	if (animationTimer) {
		[self stopAnimation];
		[self startAnimation];
	}
}

#pragma mark dealloc

- (void) dealloc
{
	[self stopAnimation];
	[inputController release];
	[openGLView release];	
	[super dealloc];
}


@end
