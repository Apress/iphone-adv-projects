//
//  BBSpaceShip.m
//  SpaceRocks
//
//  Created by ben smith on 3/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSpaceShip.h"
#import "ship_iphone.h"
#import "BBTexturedMesh.h"


@implementation BBSpaceShip

-(void)awake
{
	[[BBMaterialController sharedMaterialController] loadTextureImage:@"shipTexture.png" materialKey:@"shipTexture"];

	mesh = [[BBTexturedMesh alloc] initWithVertexes:Ship_vertex_coordinates 
																			vertexCount:Ship_vertex_array_size 
																			 vertexSize:3 
																			renderStyle:GL_TRIANGLES];
	[(BBTexturedMesh*)mesh setMaterialKey:@"shipTexture"];
	[(BBTexturedMesh*)mesh setUvCoordinates:Ship_texture_coordinates];
	[(BBTexturedMesh*)mesh setNormals:Ship_normal_vectors];
	
}





@end
