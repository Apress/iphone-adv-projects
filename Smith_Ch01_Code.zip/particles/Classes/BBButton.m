//
//  BBButton.m
//  SpaceRocks
//
//  Created by ben smith on 3/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBButton.h"


#pragma mark square
static NSInteger BBSquareVertexSize = 2;
static NSInteger BBSquareColorStride = 4;
static GLenum BBSquareOutlineRenderStyle = GL_LINE_LOOP;
static NSInteger BBSquareOutlineVertexesCount = 4;
static CGFloat BBSquareOutlineVertexes[8] = {-0.5f, -0.5f, 0.5f,  -0.5f, 0.5f,   0.5f, -0.5f,  0.5f};
static CGFloat BBSquareOutlineColorValues[16] = {1.0,0.0,0.0,1.0, 1.0,0.0,0.0,1.0, 1.0,0.0,0.0,1.0, 1.0,0.0,0.0,1.0};
static GLenum BBSquareFillRenderStyle = GL_TRIANGLE_STRIP;
static NSInteger BBSquareFillVertexesCount = 4;
static CGFloat BBSquareFillVertexes[8] = {-0.5,-0.5, 0.5,-0.5, -0.5,0.5, 0.5,0.5};


@implementation BBButton

@synthesize buttonDownAction,buttonUpAction,target,pressed,touchDownPoint;

// called once when the object is first created.
-(void)awake
{
	pressed = NO;
	mesh = [[BBMesh alloc] initWithVertexes:BBSquareOutlineVertexes vertexCount:BBSquareOutlineVertexesCount vertexSize:BBSquareVertexSize renderStyle:BBSquareOutlineRenderStyle];
	mesh.colors = BBSquareOutlineColorValues;
	mesh.colorSize = BBSquareColorStride;
	
	[self setPosition:position];
	// this is a bit rendundant, but allows for much simpler subclassing
	[self setNotPressedVertexes];
}


-(void)setPosition:(BBPoint)p
{
	position = p;
	screenRect = [[BBSceneController sharedSceneController].inputController 
								screenRectFromMeshRect:self.meshBounds 
								atPoint:CGPointMake(position.x, position.y)];	
}

// called once every frame
-(void)update:(NSTimeInterval)deltaTime
{
	// check for touches
	[self handleTouches];
	[super update:deltaTime];
}

-(void)setPressedVertexes
{
	mesh.vertexes = BBSquareFillVertexes;
	mesh.renderStyle = BBSquareFillRenderStyle;
	mesh.vertexCount = BBSquareFillVertexesCount;	
	mesh.colors = BBSquareOutlineColorValues;
}

-(void)setNotPressedVertexes
{
	mesh.vertexes = BBSquareOutlineVertexes;
	mesh.renderStyle = BBSquareOutlineRenderStyle;
	mesh.vertexCount = BBSquareOutlineVertexesCount;	
	mesh.colors = BBSquareOutlineColorValues;
}

-(void)handleTouches
{
	for (UITouch * touch in [touchEvents allObjects]) {
		CGPoint touchPoint = [touch locationInView:[touch view]];

		if (touch.phase == UITouchPhaseBegan) [self touchDown:touchPoint];						
		if (touch.phase == UITouchPhaseMoved || touch.phase == UITouchPhaseStationary) [self touchDown:touchPoint];						
		if (touch.phase == UITouchPhaseEnded) {
			[self touchUp];						
			[touchEndedEvents addObject:touch];			
		}
	}
	for (id obj in touchEndedEvents) {
		[touchEvents removeObject:obj];		
	}
}


-(void)touchUp
{
	if (!pressed) return; // we were already up
	pressed = NO;
	[self setNotPressedVertexes];
	if (buttonUpAction != nil) [target performSelector:buttonUpAction];
}

-(void)touchDown:(CGPoint)touchPoint
{
	if (pressed) return; // we were already down
	touchDownPoint = touchPoint;
	pressed = YES;
	[self setPressedVertexes];
	if (buttonDownAction != nil) [target performSelector:buttonDownAction];
}

- (void) dealloc
{
	target = nil;
	[super dealloc];
}


@end
