//
//  BBDisplay.h
//  particles
//
//  Created by ben smith on 5/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneObject.h"
@class BBNumberField;

@interface BBDisplay : BBSceneObject {
	BBNumberField * fps;
	BBNumberField * verts;
	CGFloat fpsValue;
	NSTimeInterval elapsedTime;
}


- (void) dealloc;
- (void)awake;
- (void)occasionalUpdate:(NSTimeInterval)deltaTime;
- (void)update:(NSTimeInterval)deltaTime;

// 4 methods

@end
