//
//  BBSceneThree.h
//  particles
//
//  Created by ben smith on 7/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBScene.h"


@interface BBSceneThree : BBScene {

}

@end
