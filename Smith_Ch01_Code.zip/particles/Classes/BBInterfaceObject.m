//
//  BBInterfaceObject.m
//  SkateDude
//
//  Created by ben smith on 26/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBInterfaceObject.h"


@implementation BBInterfaceObject
@synthesize screenRect,touchEvents;

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.touchEvents = [NSMutableSet set];
		touchEndedEvents = [[NSMutableArray alloc] init];
	}
	return self;
}


-(void)destroy
{
	[super destroy];
	[[BBSceneController sharedSceneController].inputController removeInterfaceObject:self];
}

-(void)addTouchEvent:(UITouch*)touchEvent
{
	[touchEvents addObject:touchEvent];
}

- (void) dealloc
{
	[touchEvents release];
	[touchEndedEvents release];
	[super dealloc];
}

@end
