//
//  BBSceneController.h
//  BBOpenGLGameTemplate
//
//  Created by ben smith on 1/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BBInputViewController;
@class EAGLView;
@class BBSceneObject;
@class BBRenderController;


@interface BBSceneController : NSObject {
	BBInputViewController * inputController;
	EAGLView * openGLView;
	BBRenderController * renderer;
	
	NSTimer *animationTimer;
	NSTimeInterval animationInterval;

	NSTimeInterval deltaTime;
	NSTimeInterval lastFrameStartTime;
	NSTimeInterval timeSinceLevelStart;
	NSDate * levelStartTime;
	
	BBSceneObject * currentScene;
	NSInteger sceneIndex;
	BOOL needToLoadScene;
	NSMutableArray * scenes;
	
	NSInteger totalVerts;
}

@property (retain) BBInputViewController * inputController;
@property (retain) EAGLView * openGLView;
@property (retain) NSDate * levelStartTime;

@property (retain) BBSceneObject * currentScene;

@property NSTimeInterval animationInterval;
@property NSTimeInterval deltaTime;
@property (nonatomic, assign) NSTimer *animationTimer;

@property (assign) NSInteger sceneIndex;
@property (assign) NSInteger totalVerts;

+ (BBSceneController*)sharedSceneController;
- (id) init;
- (void) dealloc;
- (void) startScene;
- (void)gameLoop;
- (void)loadScene:(NSInteger)sceneNumber;;
- (void)loadSceneNotification:(NSNotification*)note;
- (void)renderScene;
- (void)restartScene;
- (void)setAnimationInterval:(NSTimeInterval)interval 	;
- (void)setAnimationTimer:(NSTimer *)newTimer ;
- (void)startAnimation ;
- (void)stopAnimation ;
- (void)unloadCurrentScene;

// 14 methods



@end
