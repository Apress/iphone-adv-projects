//
//  BBDisplay.m
//  particles
//
//  Created by ben smith on 5/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBDisplay.h"
#import "BBNumberField.h"


@implementation BBDisplay
-(void)awake
{
	verts = [[BBNumberField alloc] init];
	verts.position = BBPointMake(-120.0, -100.0, 0.0);
	verts.scale = BBPointMake(0.35, 0.35, 1.0);
	verts.alignment = UITextAlignmentLeft;
	[verts setString:@"0000"];
	[self addChild:verts];

	fps = [[BBNumberField alloc] init];
	fps.position = BBPointMake(-50.0, -100.0, 0.0);
	fps.scale = BBPointMake(0.35, 0.35, 1.0);
	fps.alignment = UITextAlignmentLeft;
	[fps setString:@"00"];
	[self addChild:fps];	
		elapsedTime = 0.0;
}

-(void)update:(NSTimeInterval)deltaTime
{
	// only update once so often
	elapsedTime += deltaTime;
	if (elapsedTime > 0.25) {
		[self occasionalUpdate:deltaTime];
		elapsedTime = 0.0;
		[super update:deltaTime];
	}	
}

-(void)occasionalUpdate:(NSTimeInterval)deltaTime
{
	fpsValue = BBLerp(fpsValue, deltaTime, 0.75); // low pass filter to smooth out the fps a bit
	[fps setString:[NSString stringWithFormat:@"%d",(int)((1.0/fpsValue) + 0.5)]];
	
	[verts setString:[NSString stringWithFormat:@"%d",[BBSceneController sharedSceneController].totalVerts/6]];
	[BBSceneController sharedSceneController].totalVerts = 0;
}

- (void) dealloc
{
	[fps release];
	[verts release];
	[super dealloc];
}

@end
