//
//  BBInterfaceObject.h
//  SkateDude
//
//  Created by ben smith on 26/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneObject.h"


@interface BBInterfaceObject : BBSceneObject {
	CGRect screenRect;
	NSMutableSet * touchEvents;
	NSMutableArray * touchEndedEvents;
}

@property (assign) CGRect screenRect;
@property (retain) NSMutableSet * touchEvents;

- (id) init;
- (void) dealloc;
- (void)addTouchEvent:(UITouch*)touchEvent;
- (void)destroy;

// 4 methods


@end
