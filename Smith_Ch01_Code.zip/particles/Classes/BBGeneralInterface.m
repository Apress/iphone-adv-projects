//
//  BBGeneralInterface.m
//  particles
//
//  Created by ben smith on 5/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBGeneralInterface.h"
#import "BBTexturedButton.h"
#import "BBNumberField.h"

@implementation BBGeneralInterface
-(void)awake
{
	[[BBMaterialController sharedMaterialController] loadAtlasData:@"buttonAtlas"];
	
	BBTexturedButton* zeroButton = [[BBTexturedButton alloc] initWithUpKey:@"zeroButton" downKey:@"zeroButtonDown"];
	zeroButton.position = BBPointMake(200.0, 120.0, 0.0);	
	zeroButton.target = self;
	zeroButton.buttonDownAction = @selector(button0Down);
	zeroButton.buttonUpAction = nil;
	zeroButton.render = YES;
	[zeroButton awake];
	[[BBSceneController sharedSceneController].inputController addInterfaceObject:zeroButton];
	[zeroButton release];	
	
	
	BBTexturedButton* oneButton = [[BBTexturedButton alloc] initWithUpKey:@"oneButton" downKey:@"oneButtonDown"];
	oneButton.position = BBPointMake(200.0, 60.0, 0.0);	
	oneButton.target = self;
	oneButton.buttonDownAction = @selector(button1Down);
	oneButton.buttonUpAction = nil;
	oneButton.render = YES;
	[oneButton awake];
	[[BBSceneController sharedSceneController].inputController addInterfaceObject:oneButton];
	[oneButton release];	

	
	BBTexturedButton* twoButton = [[BBTexturedButton alloc] initWithUpKey:@"twoButton" downKey:@"twoButtonDown"];
	twoButton.position = BBPointMake(200.0, -0.0, 0.0);	
	twoButton.target = self;
	twoButton.buttonDownAction = @selector(button2Down);
	twoButton.buttonUpAction = nil;
	twoButton.render = YES;
	[twoButton awake];
	[[BBSceneController sharedSceneController].inputController addInterfaceObject:twoButton];
	[twoButton release];	

	
	BBTexturedButton* threeButton = [[BBTexturedButton alloc] initWithUpKey:@"threeButton" downKey:@"threeButtonDown"];
	threeButton.position = BBPointMake(200.0, -60.0, 0.0);	
	threeButton.target = self;
	threeButton.buttonDownAction = @selector(button3Down);
	threeButton.buttonUpAction = nil;
	threeButton.render = YES;
	[threeButton awake];
	[[BBSceneController sharedSceneController].inputController addInterfaceObject:threeButton];
	[threeButton release];	
	
	BBTexturedButton* fourButton = [[BBTexturedButton alloc] initWithUpKey:@"fourButton" downKey:@"fourButtonDown"];
	fourButton.position = BBPointMake(200.0, -120.0, 0.0);	
	fourButton.target = self;
	fourButton.buttonDownAction = @selector(button4Down);
	fourButton.buttonUpAction = nil;
	fourButton.render = YES;
	[fourButton awake];
	[[BBSceneController sharedSceneController].inputController addInterfaceObject:fourButton];
	[fourButton release];	
}	

-(void)loadScene:(NSInteger)sceneNumber
{
	[[NSNotificationCenter defaultCenter] postNotificationName:@"BBLoadScene" object:[NSNumber numberWithInteger:sceneNumber]];	
}

-(void)button0Down
{
	[self loadScene:0];
}


-(void)button1Down
{
	[self loadScene:1];
}


-(void)button2Down
{
	[self loadScene:2];
}


-(void)button3Down
{
	[self loadScene:3];
}

-(void)button4Down
{
	[self loadScene:4];
}



@end
