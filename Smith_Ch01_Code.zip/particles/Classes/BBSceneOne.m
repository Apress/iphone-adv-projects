//
//  BBSceneOne.m
//  particles
//
//  Created by ben smith on 6/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneOne.h"

#import "BBSpaceShip.h"
#import "BBUFO.h"
#import "BBMissile.h"

@implementation BBSceneOne
-(void)awake
{
	[super awake];
	[[BBMaterialController sharedMaterialController] loadAtlasData:@"particleAtlas"];
	
	particles = [[BBParticleSystem alloc] init];
	particles.position = BBPointMake(-120.0, 80.0, -50.0);
	[particles setParticle:@"whiteSubtle"];
	
	// thruster
	particles.emissionRange = BBRangeMake(50,50);
	particles.xVelocityRange = BBRangeMake(40, 40);
	particles.yVelocityRange = BBRangeMake(-5, 10);
	particles.zVelocityRange = BBRangeMake(-5, 10);
	
	particles.growRange = BBRangeMake(-1.5, 0.5);	
	particles.sizeRange = BBRangeMake(2, 8);
	
	particles.lifeRange = BBRangeMake(5.0, 0.0);
	particles.decayRange = BBRangeMake(1, 1);

	//	
	
	[self addChild:particles];
	
	particles2 = [[BBParticleSystem alloc] init];
	particles2.position = BBPointMake(-120.0, 10.0, -50.0);
	
	// thruster
	particles2.emissionRange = BBRangeMake(100,50);
	particles2.xVelocityRange = BBRangeMake(80, 20);
	particles2.yVelocityRange = BBRangeMake(-12, 24);
	particles2.zVelocityRange = BBRangeMake(-5, 10);
	
	particles2.growRange = BBRangeMake(-8.5, 3.0);	
	particles2.sizeRange = BBRangeMake(6, 2);
	
	particles2.lifeRange = BBRangeMake(1.0, 0.0);
	particles2.decayRange = BBRangeMake(1, 1);
  //	
	
	[particles2 setParticle:@"lightBlur"];
	[self addChild:particles2];
	
	particles3 = [[BBParticleSystem alloc] init];
	particles3.position = BBPointMake(-120.0, -60.0, -50.0);
	
	// thruster
	particles3.emissionRange = BBRangeMake(100,500);
	particles3.xVelocityRange = BBRangeMake(80, 20);
	particles3.yVelocityRange = BBRangeMake(-12, 24);
	particles3.zVelocityRange = BBRangeMake(-5, 10);
	
	particles3.growRange = BBRangeMake(-1.5, 3.0);	
	particles3.sizeRange = BBRangeMake(1, 2);
	
	particles3.lifeRange = BBRangeMake(2.0, 1.0);
	particles3.decayRange = BBRangeMake(1, 1);
  //	
	
	[particles3 setParticle:@"redBlur"];
	[self addChild:particles3];

	// add ships
	// uncomment this out if you want to see the ships
	// [self addShips];
}

-(void)emitButtonDown
{
	particles.emit = YES;
	particles2.emit = YES;
	particles3.emit = YES;
}

-(void)emitButtonUp
{
	particles.emit = NO;
	particles2.emit = NO;
	particles3.emit = NO;
}


-(void)addShips
{
	BBSpaceShip * ship = [[BBSpaceShip alloc] init];
	ship.position = BBPointMake(-130.0, 80.0, -50.0);
	ship.rotation = BBPointMake(0.0, 5.0, 90.0);
	ship.scale = BBPointMake(30, 30, 30);
	[self addChild:ship];
	[ship release];		

	BBUFO * ufo = [[BBUFO alloc] init];
	ufo.position = BBPointMake(-130.0, 10.0, -50.0);
	ufo.rotation = BBPointMake(0.0, 0.0, 90.0);
	ufo.scale = BBPointMake(30, 30, 30);
	[self addChild:ufo];
	[ufo release];

	BBMissile * rocket = [[BBMissile alloc] init];
	rocket.position = BBPointMake(-130.0, -60.0, -50.0);
	rocket.rotation = BBPointMake(0.0, 0.0, 90.0);
	rocket.scale = BBPointMake(5, 5, 5);
	[self addChild:rocket];
	[rocket release];
	
	
	
	
}


- (void) dealloc
{
	[particles2 release];
	[particles3 release];
	[super dealloc];
}


@end
