//
//  BBSceneObject.h
//  BBOpenGLGameTemplate
//
//  Created by ben smith on 1/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#import <QuartzCore/QuartzCore.h>

#import "BBMesh.h"
#import "BBGameTypes.h"
#import "BBSceneController.h";
#import "BBInputViewController.h";
#import "BBMaterialController.h";
#import "BBTexturedQuad.h"
#import "BBGameTypes.h";
#import "BBConfiguration.h";


@interface BBSceneObject : NSObject {
	NSMutableArray * children;
	NSMutableArray * objectsToRemove;
	NSMutableArray * objectsToAdd;	
	
	// transform values
	BBPoint position;
	BBPoint rotation;
	BBPoint scale;

	BOOL render;
	BOOL onscreen;

	BBMesh * mesh;
	
	CGFloat * matrix;
	CGFloat depth;
	
	CGRect meshBounds;
		
	BBSceneObject * parent;
}

@property (assign) CGRect meshBounds;
@property (retain) BBSceneObject * parent;
@property (readonly) NSMutableArray* children;
@property (retain) BBMesh * mesh;

@property (assign) CGFloat depth;
@property (assign) BBPoint position;
@property (assign) CGFloat * matrix;
@property (assign) BBPoint rotation;
@property (assign) BBPoint scale;

@property (assign) BOOL render;
@property (assign) BOOL onscreen;

- (BOOL)isOnscreen;
- (CGRect) meshBounds;
- (id) init;
- (void) dealloc;
- (void)addChild:(BBSceneObject*)sceneObject;
- (void)awake;
- (void)destroy;
- (void)postLoopProcess;
- (void)preLoopProcess;
- (void)removeAllChildren;
- (void)removeChild:(id)sceneObject;
- (void)update:(NSTimeInterval)deltaTime;

// 12 methods





@end
