//
//  BBMissile.m
//  SpaceRocks
//
//  Created by ben smith on 5/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBMissile.h"
#import "BBTexturedMesh.h"
#import "missile_iphone.h"

#pragma mark Missile mesh

@implementation BBMissile

-(void)awake
{
	[[BBMaterialController sharedMaterialController] loadTextureImage:@"missileTexture.png" materialKey:@"missileTexture"];

	mesh = [[BBTexturedMesh alloc] initWithVertexes:Missile_vertex_coordinates 
																			vertexCount:Missile_vertex_array_size 
																			 vertexSize:3 
																			renderStyle:GL_TRIANGLES];
	[(BBTexturedMesh*)mesh setMaterialKey:@"missileTexture"];
	[(BBTexturedMesh*)mesh setUvCoordinates:Missile_texture_coordinates];
	[(BBTexturedMesh*)mesh setNormals:Missile_normal_vectors];
	
}

@end
