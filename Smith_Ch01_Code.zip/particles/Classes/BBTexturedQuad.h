//
//  BBTexturedQuad.h
//  SpaceRocks
//
//  Created by ben smith on 14/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBMesh.h"
#import "BBMaterialController.h"


@interface BBTexturedQuad : BBMesh {
	GLfloat * uvCoordinates;
	NSString * materialKey;
	BBPoint offset;
	NSString * atlasKey;
	BOOL useColors;
}

@property (assign) GLfloat * uvCoordinates;
@property (assign) BBPoint offset;
@property (retain) NSString * materialKey;
@property (retain) NSString * atlasKey;
@property (assign) BOOL useColors;

- (id) initWithQuadSize:(CGSize)size;
- (void) dealloc;
- (void)render;

// 3 methods



@end
