//
//  BBMaterialController.h
//  SpaceRocks
//
//  Created by ben smith on 14/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#import <QuartzCore/QuartzCore.h>
#import "BBGameTypes.h";
#import "BBConfiguration.h";

@class BBTexturedQuad;

@interface BBMaterialController : NSObject {
	NSMutableDictionary * materialLibrary;
	NSMutableDictionary * quadLibrary;
	NSMutableDictionary * collisionMeshLibrary;
}

+ (BBMaterialController*)sharedMaterialController;
- (BBTexturedQuad*)quadFromAtlasKey:(NSString*)atlasKey;
- (BBTexturedQuad*)texturedQuadFromAtlasRecord:(NSDictionary*)record 
																		 atlasSize:(CGSize)atlasSize
																	 materialKey:(NSString*)key;;
- (CGSize)loadTextureImage:(NSString*)imageName materialKey:(NSString*)materialKey;
- (void) dealloc;
- (void)bindMaterial:(NSString*)materialKey;
- (void)loadAtlasData:(NSString*)atlasName;
- (void)purgeAllMaterials;
- (void)purgeMaterial:(NSString*)materialKey;

// 9 methods





@end
