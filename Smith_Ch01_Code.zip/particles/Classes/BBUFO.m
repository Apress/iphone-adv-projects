//
//  BBUFO.m
//  SpaceRocks3D
//
//  Created by ben smith on 31/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBUFO.h"
#import "ufo_iphone.h"
#import "BBTexturedMesh.h"


@implementation BBUFO
-(void)awake
{
	[[BBMaterialController sharedMaterialController] loadTextureImage:@"ufoTexture.png" materialKey:@"ufoTexture"];

	mesh = [[BBTexturedMesh alloc] initWithVertexes:UFO_vertex_coordinates 
																			vertexCount:UFO_vertex_array_size 
																			 vertexSize:3 
																			renderStyle:GL_TRIANGLES];
	[(BBTexturedMesh*)mesh setMaterialKey:@"ufoTexture"];
	[(BBTexturedMesh*)mesh setUvCoordinates:UFO_texture_coordinates];
	[(BBTexturedMesh*)mesh setNormals:UFO_normal_vectors];
	
}


@end
