//
//  BBButton.h
//  SpaceRocks
//
//  Created by ben smith on 3/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBInterfaceObject.h"

@interface BBButton : BBInterfaceObject {
	BOOL pressed;
	id target;
	SEL buttonDownAction;
	SEL buttonUpAction;
	CGPoint touchDownPoint;
}

@property (assign) id target;
@property (assign) BOOL pressed;
@property (assign) SEL buttonDownAction;
@property (assign) SEL buttonUpAction;
@property (assign) CGPoint touchDownPoint;

- (void) dealloc;
- (void)awake;
- (void)handleTouches;
- (void)setNotPressedVertexes;
- (void)setPosition:(BBPoint)p;
- (void)setPressedVertexes;
- (void)touchDown:(CGPoint)touchPoint;
- (void)touchUp;
- (void)update:(NSTimeInterval)deltaTime;

// 9 methods

@end
