//
//  BBScene.h
//  particles
//
//  Created by ben smith on 6/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBSceneObject.h"
#import "BBParticleSystem.h"


@interface BBScene : BBSceneObject {
	BBSceneObject * uiObject;
	BBParticleSystem * particles;
}

@end
