//
//  Push2ViewController.h
//  Push2
//
//  Created by Joe Pezzillo on 9/6/09.
//  Copyright Joe Pezzillo 2009. All rights reserved.
//
//  DISCLAIMER:
//  PROVIDED AS IS WITHOUT WARRANTY OR REPRESENTATION OF ANY KIND.
//	YOU ARE SOLELY RESPONSIBLE FOR ITS USE AT YOUR OWN RISK.
//
//
//

#import <UIKit/UIKit.h>

@interface Push2ViewController : UIViewController {

	IBOutlet UITextView  *messageTextView;
	IBOutlet UILabel	 *deviceTokenField;
	IBOutlet UITextField *userNameField;
	
}

-(IBAction)handleSendButton:(id)sender;
-(void)handleSetDeviceTokenField:(NSString *)inDeviceToken;
-(void)handleDidReceiveRemoteNotification:(NSDictionary *)userInfo;

@end

