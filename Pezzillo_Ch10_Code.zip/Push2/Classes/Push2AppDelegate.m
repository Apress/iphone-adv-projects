//
//  Push2AppDelegate.m
//  Push2
//
//  Created by Joe Pezzillo on 9/6/09.
//  Copyright Joe Pezzillo 2009. All rights reserved.
//
//  DISCLAIMER:
//  PROVIDED AS IS WITHOUT WARRANTY OR REPRESENTATION OF ANY KIND.
//	YOU ARE SOLELY RESPONSIBLE FOR ITS USE AT YOUR OWN RISK.
//
//

#import "Push2AppDelegate.h"
#import "Push2ViewController.h"

@implementation Push2AppDelegate

@synthesize window;
@synthesize viewController;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	
	// launchOptions has the incoming notification if we're being launched after the user tapped "view"
	NSLog( @"didFinishLaunchingWithOptions:%@", launchOptions );
	
	//	[self.viewController handleDidReceiveRemoteNotification:userInfo];

	
	// other setup tasks here.... 
    [[UIApplication sharedApplication] 
	 registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | 
										 UIRemoteNotificationTypeSound |
										 UIRemoteNotificationTypeAlert)]; 
	
    // [self updateWithRemoteData];  // freshen your app!
	
	// RESET THE BADGE COUNT
    application.applicationIconBadgeNumber = 0; 
	
    // ... 
	// call the original applicationDidFinishLaunching method to handle the basic view setup tasks
	[self applicationDidFinishLaunching:application];
	
	return YES;
}

- (void)application:(UIApplication *)app 
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)devToken { 
    [self sendDeviceTokenToRemote:devToken]; // send the token to your server 
}

- (void)application:(UIApplication *)app 
didFailToRegisterForRemoteNotificationsWithError:(NSError *)err { 
    NSLog(@"Failed to register, error: %@", err); 
} 

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
	NSLog( @"didReceiveRemoteNotification:%@", userInfo );
	[self.viewController handleDidReceiveRemoteNotification:userInfo];

}

-(void)sendDeviceTokenToRemote:(NSData *)deviceToken
{
	NSLog( @"sendDeviceTokenToRemote:%@", deviceToken );
	
	NSString *inDeviceTokenStr = [deviceToken description];
	NSString *tokenString = [inDeviceTokenStr stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"< >"]];
	tokenString = [tokenString stringByReplacingOccurrencesOfString:@" " withString:@""];
	
	// send it to the remote server
	
	// do we have a username for this user? probably not yet
	
	NSString *hostString = @"http://2push2.us/apress/apress.php";
	NSString *nameString = @"2Push2Test";
	NSString *argsString = @"%@?token=%@&cmd=reg&name=%@";
	NSString *getURLString = [NSString stringWithFormat:argsString,hostString,tokenString,nameString];
	NSString *registerResult = [NSString stringWithContentsOfURL:[NSURL URLWithString:getURLString]];
	
	NSLog( @"registerResult:%@", registerResult );
	
	// display it in the field on the view controller
	[self.viewController handleSetDeviceTokenField:tokenString];
	
}


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
