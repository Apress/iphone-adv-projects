//
//  Push2AppDelegate.h
//  Push2
//
//  Created by Joe Pezzillo on 9/6/09.
//  Copyright Joe Pezzillo 2009. All rights reserved.
//
//  DISCLAIMER:
//  PROVIDED AS IS WITHOUT WARRANTY OR REPRESENTATION OF ANY KIND.
//	YOU ARE SOLELY RESPONSIBLE FOR ITS USE AT YOUR OWN RISK.
//
//


#import <UIKit/UIKit.h>

@class Push2ViewController;

@interface Push2AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    Push2ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Push2ViewController *viewController;

-(void)sendDeviceTokenToRemote:(NSData *)deviceToken;

@end

