//
//  Push2ViewController.m
//  Push2
//
//  Created by Joe Pezzillo on 9/6/09.
//  Copyright Joe Pezzillo 2009. All rights reserved.
//
//  DISCLAIMER:
//  PROVIDED AS IS WITHOUT WARRANTY OR REPRESENTATION OF ANY KIND.
//	YOU ARE SOLELY RESPONSIBLE FOR ITS USE AT YOUR OWN RISK.
//
//
//

#import "Push2ViewController.h"

@implementation Push2ViewController

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

-(IBAction)handleSendButton:(id)sender
{
	NSLog( @"handleSendButton" );
	
	// make a get request to our script with the msg parameter set
	// msg=URLENCODEDSTRING;
	
	NSLog( @"userNameField.text:%@", userNameField.text );
	
	CFStringRef outString = CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)messageTextView.text, NULL, NULL, kCFStringEncodingUTF8);
	
	NSString *urlFormatString = @"http://2push2.us/apress/apress.php?token=%@&cmd=msg&name=%@&msg=%@";
	
	NSURL *composedURL = [NSURL URLWithString:[NSString stringWithFormat:urlFormatString,deviceTokenField.text,userNameField.text,(NSString *)outString]];
	
	NSLog( @"composedURL:%@", composedURL );
	
	// would almost always generally be better to do this asyncronously with NSURLConnection
	NSString *result = [NSString stringWithContentsOfURL:composedURL];
	
	NSLog( @"result:%@", result );
	
	CFRelease(outString);
	
}

-(void)handleSetDeviceTokenField:(NSString *)inDeviceToken
{
	NSLog( @"handleSetDeviceTokenField:%@", inDeviceToken );
	deviceTokenField.text = inDeviceToken;
}

-(void)handleDidReceiveRemoteNotification:(NSDictionary *)userInfo
{
	
	NSDictionary *aps = [userInfo valueForKey:@"aps"];
	NSString *alert = [aps valueForKey:@"alert"];
	
	// this is custom field sent from the server, currently just the submitted username
	NSString *sender = [userInfo valueForKey:@"custom"];
	
	messageTextView.text = [NSString stringWithFormat:@"%@ sent: %@", sender, alert];
	
}


@end
