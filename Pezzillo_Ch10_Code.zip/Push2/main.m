//
//  main.m
//  Push2
//
//  Created by Joe Pezzillo on 9/6/09.
//  Copyright Joe Pezzillo 2009. All rights reserved.
//
//  DISCLAIMER:
//  PROVIDED AS IS WITHOUT WARRANTY OR REPRESENTATION OF ANY KIND.
//	YOU ARE SOLELY RESPONSIBLE FOR ITS USE AT YOUR OWN RISK.
//
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
